//
//  swanType.h
//  iSSwan
//
//  Created by Jingjing Deng on 24/04/2015.
//
//

#ifndef iSSwan_swanType_h
#define iSSwan_swanType_h

#include <stdio.h>
#include <vector>
#include <eigen3/Eigen/Core>
#include <eigen3/Eigen/SparseCore>
#include <eigen3/Eigen/Sparse>
#include <eigen3/Eigen/SparseQR>
#include <eigen3/Eigen/SparseLU>
#include <eigen3/Eigen/SparseCholesky>
#include <eigen3/Eigen/IterativeLinearSolvers>
#include <eigen3/Eigen/UmfPackSupport>
#include <eigen3/Eigen/OrderingMethods>

// Primitive Type
typedef float           NumberFloat32;
typedef double          NumberDouble64;
typedef char            NumberSByte08;
typedef short           NumberSInteger16;
typedef int             NumberSInteger32;
typedef unsigned char   NumberUByte08;
typedef unsigned short  NumberUInteger16;
typedef unsigned int    NumberUInteger32;

// Intermediate Type
typedef NumberFloat32       USERReal32;
typedef NumberDouble64      USERReal64;


// Geometry Type
typedef struct __Point3D__ {
    USERReal64 X;
    USERReal64 Y;
    USERReal64 Z;
}Point3D;

typedef std::vector<Point3D> Point3DSet;

// Algebra Type
typedef Eigen::SparseMatrix<USERReal64>   SparseMat;
typedef Eigen::Matrix<USERReal64, 1, 4>   RowVector4;
typedef Eigen::Matrix<USERReal64, 4, 1>   ColVector4;
typedef Eigen::Matrix<USERReal64, 7, 1>   ColVector7;
typedef Eigen::Matrix<USERReal64, 4, 4>   SqrMatrix4;
typedef Eigen::MatrixXd                   SqrMatrixX;
typedef Eigen::Triplet<USERReal64>        Triplet;
typedef Eigen::VectorXd                   ColVectorX;
typedef Eigen::VectorXd                   RowVectorX;

typedef Eigen::UmfPackLU<SparseMat>                             SparseSolver_UmfPackLU;
typedef Eigen::SimplicialLLT<SparseMat>                         SparseSolver_SimplicialLLT;
typedef Eigen::SparseLU<SparseMat>                              SparseSolver_LU;
typedef Eigen::SparseQR<SparseMat, Eigen::COLAMDOrdering<int>>  SparseSolver_QR;
typedef Eigen::ConjugateGradient<SparseMat>                     SparseSolver_ConjuGrad;

#endif
