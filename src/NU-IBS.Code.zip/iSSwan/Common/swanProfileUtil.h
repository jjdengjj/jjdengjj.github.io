//
//  swanProfileUtil.h
//  iSSwan
//
//  Created by J. Deng on 03/12/2014.
//  Copyright (c) 2014 J. Deng. All rights reserved.
//

#ifndef __iSSwan__swanProfileUtil__
#define __iSSwan__swanProfileUtil__

#include <stdio.h>
#include <string>
#include <ctime>
#include <vector>

namespace csvision {
    
    class swanProfileUtil
    {
    public:
        swanProfileUtil();
        ~swanProfileUtil();
        
    public:
        typedef enum _enumLogLevel {
            LogLevel_ERROR = 0,
            LogLevel_WARNNING = 1,
            LogLevel_NORMAL = 2
        }_typeLogLevel;
        
        typedef struct _structLog
        {
            std::time_t     happend;
            std::clock_t    clockt;
            std::string     name;
            std::string     source;
            _typeLogLevel   level;
            std::string     message;
        } _typeLog;
        
        static const bool DEBUGON = true;
        static const bool DEBUGOFF = false;
        static const bool LOGON = true;
        static const bool LOGOFF = false;
        static const std::string LOGFILENAME;
        static const long CPUFreq = CLOCKS_PER_SEC;
    private:
        bool                        IsDebug;
        bool                        IsLog;
        std::vector<_typeLog>       Log;
        std::string                 ObjectName;
    public:
        void        save(std::string filename);
        void        setDebugON();
        void        setDebugOFF();
        void        setLogON();
        void        setLogOFF();
        void        setObjectName(std::string on);
        std::string getObjectName();
        void        AddLogNormal(std::string name, std::string source, std::string message);
        void        AddLogWarning(std::string name, std::string source, std::string message);
        void        AddLogError(std::string name, std::string source, std::string message);
    };
    
}

#endif /* defined(__iSSwan__swanProfileUtil__) */
