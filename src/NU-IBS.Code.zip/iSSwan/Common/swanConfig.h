//
//  swanConfig.h
//  iSSwan
//
//  Created by Jingjing Deng on 26/04/2015.
//
//

#ifndef iSSwan_swanConfig_h
#define iSSwan_swanConfig_h

#ifndef __PROFILE__
#define __PROFILE__
#endif

//#ifndef __DEBUG__
//#define __DEBUG__
//#endif

#ifndef __NUMBER_OF_THREADS__
#define __NUMBER_OF_THREADS__ 8
#endif

#endif
