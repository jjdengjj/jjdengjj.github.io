//
//  swanProfileUtil.cpp
//  iSSwan
//
//  Created by J. Deng on 03/12/2014.
//  Copyright (c) 2014 J. Deng. All rights reserved.
//

#include "swanProfileUtil.h"
#include <stdio.h>
#include <iostream>
#include <fstream>
#include <iomanip>
#include <time.h>

using namespace csvision;


swanProfileUtil::swanProfileUtil()
{
    IsDebug = swanProfileUtil::DEBUGOFF;
    IsLog = swanProfileUtil::LOGON;
    ObjectName = "UNKNOWN";
    AddLogNormal("swanProfileUtil Init", "swanProfileUtil.cpp:getInstance()", "Debugger Init");
    IsDebug = swanProfileUtil::DEBUGON;
}

swanProfileUtil::~swanProfileUtil()
{
    
}

void swanProfileUtil::save(std::string filename)
{
    std::ofstream logfile;
    logfile.open(filename, std::ios_base::trunc);
    if(logfile.is_open())
    {
        for(int i = 0; i < Log.size(); i++){
            _typeLog l = Log.at(i);
            long index = Log.size()-2;
            if(index<0)
                index = 0;
            _typeLog s = Log[0];
            _typeLog p = Log[index];
            
            char tbuffer[256];
            struct tm* timeinfo = localtime (&l.happend);
            std::strftime(tbuffer, 256, "%a %b %d %H:%M:%S %Y", timeinfo);
            
            double diffsecs = difftime(l.happend, s.happend);
            double diffsecp = difftime(l.happend, p.happend);
            
            logfile<<">---------------------------------------------"<<ObjectName<<" : NORMAL ("<<i<<")"<<"------------------------------------------------<"<<std::endl;
            logfile<<"Time: "<<tbuffer<<"; (+TS): " <<diffsecs<<"s; (+TP):"<<diffsecp<<"s; Clock: (+CS): "<<double(l.clockt-s.clockt)/CPUFreq<<"s; (+CP): "<<double(l.clockt-p.clockt)/CPUFreq<<"s;"<<std::endl;
            logfile<<"Event: "<<l.name<<"; From: "<<l.source<<"; Tip: " <<l.message<<";"<<std::endl;
        }
        logfile.flush();
        logfile.close();
        
    }
}

void swanProfileUtil::setDebugON()
{
    this->IsDebug = swanProfileUtil::DEBUGON;
}

void swanProfileUtil::setDebugOFF()
{
    this->IsDebug = swanProfileUtil::DEBUGOFF;
}

void swanProfileUtil::setLogON()
{
    this->IsLog = swanProfileUtil::LOGON;
}

void swanProfileUtil::setLogOFF()
{
    this->IsLog = swanProfileUtil::LOGOFF;
}

void swanProfileUtil::setObjectName(std::string on)
{
    this->ObjectName = on;
}
std::string swanProfileUtil::getObjectName()
{
    return this->ObjectName;
}

void swanProfileUtil::AddLogNormal(std::string name, std::string source, std::string message)
{
    _typeLog l;
    l.happend = time(0);
    l.clockt = clock();
    l.level = LogLevel_NORMAL;
    l.name = name;
    l.source = source;
    l.message = message;
    Log.push_back(l);
    
    if(IsDebug){
        long index = Log.size()-2;
        if(index<0)
            index = 0;
        _typeLog s = Log[0];
        _typeLog p = Log[index];
        
        char tbuffer[256];
        struct tm* timeinfo = localtime (&l.happend);
        std::strftime(tbuffer, 256, "%a %b %d %H:%M:%S %Y", timeinfo);
        
        double diffsecs = difftime(l.happend, s.happend);
        double diffsecp = difftime(l.happend, p.happend);
        
        std::cout<<">---------------------------------------------"<<ObjectName<<" : NORMAL ("<<Log.size()<<")"<<"------------------------------------------------<"<<std::endl;
        std::cout<<"Time: "<<tbuffer<<"; (+TS): " <<diffsecs<<"s; (+TP):"<<diffsecp<<"s; Clock: (+CS): "<<double(l.clockt-s.clockt)/CPUFreq<<"s; (+CP): "<<double(l.clockt-p.clockt)/CPUFreq<<"s;"<<std::endl;
        std::cout<<"Event: "<<name<<"; From: "<<source<<"; Tip: " <<message<<";"<<std::endl;
    }
}

void swanProfileUtil::AddLogWarning(std::string name, std::string source, std::string message)
{
    _typeLog l;
    l.happend = time(0);
    l.clockt = clock();
    l.level = LogLevel_WARNNING;
    l.name = name;
    l.source = source;
    l.message = message;
    Log.push_back(l);
    
    if(IsDebug){
        long index = Log.size()-2;
        if(index<0)
            index = 0;
        _typeLog s = Log[0];
        _typeLog p = Log[index];
        
        char tbuffer[256];
        struct tm* timeinfo = localtime (&l.happend);
        std::strftime(tbuffer, 256, "%a %b %d %H:%M:%S %Y", timeinfo);
        
        double diffsecs = difftime(l.happend, s.happend);
        double diffsecp = difftime(l.happend, p.happend);
        
        std::cout<<">---------------------------------------------"<<ObjectName<<" : WARNING ("<<Log.size()<<")"<<"------------------------------------------------<"<<std::endl;
        std::cout<<"Time: "<<tbuffer<<"; (+TS): " <<diffsecs<<"s; (+TP):"<<diffsecp<<"s; Clock: (+CS): "<<double(l.clockt-s.clockt)/CPUFreq<<"s; (+CP): "<<double(l.clockt-p.clockt)/CPUFreq<<"s;"<<std::endl;
        std::cout<<"Event: "<<name<<"; From: "<<source<<"; Tip: " <<message<<";"<<std::endl;
    }
}

void swanProfileUtil::AddLogError(std::string name, std::string source, std::string message)
{
    _typeLog l;
    l.happend = time(0);
    l.clockt = clock();
    l.level = LogLevel_ERROR;
    l.name = name;
    l.source = source;
    l.message = message;
    Log.push_back(l);
    
    if(IsDebug){
        long index = Log.size()-2;
        if(index<0)
            index = 0;
        _typeLog s = Log[0];
        _typeLog p = Log[index];
        
        char tbuffer[256];
        struct tm* timeinfo = localtime (&l.happend);
        std::strftime(tbuffer, 256, "%a %b %d %H:%M:%S %Y", timeinfo);
        
        double diffsecs = difftime(l.happend, s.happend);
        double diffsecp = difftime(l.happend, p.happend);
        
        std::cout<<">---------------------------------------------"<<ObjectName<<" : ERROR ("<<Log.size()<<")"<<"------------------------------------------------<"<<std::endl;
        std::cout<<"Time: "<<tbuffer<<"; (+TS): " <<diffsecs<<"s; (+TP):"<<diffsecp<<"s; Clock: (+CS): "<<double(l.clockt-s.clockt)/CPUFreq<<"s; (+CP): "<<double(l.clockt-p.clockt)/CPUFreq<<"s;"<<std::endl;
        std::cout<<"Event: "<<name<<"; From: "<<source<<"; Tip: " <<message<<";"<<std::endl;
    }
}

