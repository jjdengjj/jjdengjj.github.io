//
//  main.cpp
//  Profile
//
//  Created by Jingjing Deng on 23/04/2015.
//
//

#include <iostream>
#include "swanIBSplineProfile.hpp"

int main(int argc, const char * argv[]) {
    csvision::profile::swanIBSplineVTKImageSegmentFilter_ExpBatchRun();
    //csvision::profile::swanIBSplineVTKImageSegmentFilter_TestingNonUniform();
    return 0;
}
