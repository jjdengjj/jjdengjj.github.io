//
//  swanIBSplineTesting.hpp
//  iSSwan
//
//  Created by Jingjing Deng on 28/04/2015.
//
//

#ifndef iSSwan_swanIBSplineProfile_hpp
#define iSSwan_swanIBSplineProfile_hpp

#include "swanIBSplineVTKImageSegmentFilter.h"
#include "swanVTKImageSynthesiser.h"
#include "swanProfileUtil.h"
#include "swanVTKImageIO.hpp"

#include <vtkImageData.h>
#include <vtkSmartPointer.h>
#include <vtkImageCast.h>
#include <vtkXMLImageDataWriter.h>

#include <dirent.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>

namespace csvision {
    typedef struct __IBSParameters__{
        int nItor;
        int nBSpline;
        int nSampleRate;
        int Regular;
    }IBSParameters;
    
    namespace profile {

/*==============================================================================================================================================*/
        void swanIBSplineVTKImageSegmentFilter_TestingSynthCubeSS(){
            swanProfileUtil Profiler;
            Profiler.setObjectName("swanIBSplineProfile.hpp:swanIBSplineVTKImageSegmentFilter_TestingSynthCubeSS()");
            
#ifdef __PROFILE__
            Profiler.AddLogNormal("Syntheize Data", "swanIBSplineProfile", "Start");
#endif
            vtkSmartPointer<vtkImageData> image = vtkSmartPointer<vtkImageData>::New();
            vtkSmartPointer<vtkImageData> signs = vtkSmartPointer<vtkImageData>::New();
            swanVTKImageSynthesiser::getInstance()->SynthCubeSS(image, signs);
            vtkSmartPointer<vtkImageCast> shape = vtkSmartPointer<vtkImageCast>::New();
            shape->SetInputData(image);
            shape->SetOutputScalarTypeToUnsignedChar();
            shape->Update();
#ifdef __PROFILE__
            Profiler.AddLogNormal("Syntheize Data", "swanIBSplineProfile", "End");
#endif
          
#ifdef __PROFILE__
            Profiler.AddLogNormal("Segment Data", "swanIBSplineProfile", "Start");
#endif
            vtkSmartPointer<swanIBSplineVTKImageSegmentFilter> segment = vtkSmartPointer<swanIBSplineVTKImageSegmentFilter>::New();
#ifdef __PROFILE__
            segment->Profiler.setObjectName("swanIBSplineProfile.hpp:swanIBSplineVTKImageSegmentFilter_TestingSynthCubeSS:segment");
#endif
            segment->SetInputData(0, image);
            segment->SetInputData(1, shape->GetOutput());
            segment->SetnItor(0);
            segment->SetNumberOfBSpline(20);
            segment->SetImageSampleRate(16);
            segment->Update();
#ifdef __PROFILE__
            Profiler.AddLogNormal("Segment Data", "swanIBSplineProfile", "End");
#endif
           
#ifdef __PROFILE__
            Profiler.AddLogNormal("Save Data", "swanIBSplineProfile", "Start");
#endif
            //Save to disk
            VTKImageSaveToTIF("/Users/deng/Desktop/Volume.tif", segment->GetOutput());
#ifdef __PROFILE__
            Profiler.AddLogNormal("Save Data", "swanIBSplineProfile", "End");
#endif
        };
        
        
/*==============================================================================================================================================*/
        void swanIBSplineVTKImageSegmentFilter_TestingNonUniform(){
            swanProfileUtil Profiler;
            Profiler.setObjectName("swanIBSplineProfile.hpp:swanIBSplineVTKImageSegmentFilter_TestingNonUniform");
            Profiler.setDebugOFF();
            
#ifdef __PROFILE__
            Profiler.AddLogNormal("Read Data", "swanIBSplineProfile", "Start");
#endif
            vtkSmartPointer<vtkImageData> image = vtkSmartPointer<vtkImageData>::New();
            VTKImageLoadFromTIF("/Users/deng/Desktop/Bunny.tif", image);
            
            int exts[6] = {0};
            image->GetExtent(exts);
            double ospas[3] = {0.0};
            image->GetSpacing(ospas);
            double nspas[3] = {1.0/(exts[1]-exts[0]), 1.0/(exts[3]-exts[2]), 1.0/(exts[5]-exts[4])};
            image->SetSpacing(nspas);
            
            vtkSmartPointer<vtkImageCast> shape = vtkSmartPointer<vtkImageCast>::New();
            shape->SetInputData(image);
            shape->SetOutputScalarTypeToUnsignedChar();
            shape->Update();
            
            //Uniform 10
//            int DX[7] = {36,72,108,144,180,216,255};
//            int DY[7] = {36,72,108,144,180,216,257};
//            int DZ[7] = {29,58,87,116,145,174,201};
            
            //Non-Uniform 10
//            int DX[7] = {77,137,163,185,206,228,255};
//            int DY[7] = {36,77,121,183,211,232,257};
//            int DZ[7] = {25,41,59,83,142,176,201};
            
            //Non-Uniform 15
            int DX[12] = {45,99,129,148,162,175,188,200,212,225,239,255};
            int DY[12] = {23,44,68,89,116,160,186,203,217,229,241,257};
            int DZ[12] = {18,28,38,48,59,72,89,125,158,175,189,201};
            
#ifdef __PROFILE__
            Profiler.AddLogNormal("Read Data", "swanIBSplineProfile", "End");
#endif
            
            vtkSmartPointer<swanIBSplineVTKImageSegmentFilter> segment = vtkSmartPointer<swanIBSplineVTKImageSegmentFilter>::New();
            //segment->setCoreHelperPath("/Users/deng/Desktop/IBSHelper");
            segment->SetDensity(DX, DY, DZ);
            segment->SetisNonUniform(true);
#ifdef __PROFILE__
            segment->Profiler.setObjectName("swanIBSplineProfile.hpp:swanIBSplineVTKImageSegmentFilter_TestingNonUniform:segment");
            segment->Profiler.setDebugOFF();
#endif
            segment->SetInputData(0, image);
            segment->SetInputData(1, shape->GetOutput());
            segment->SetnItor(0);
            segment->SetNumberOfBSpline(15);
            segment->SetImageSampleRate(5);
            segment->SetRegular(swanIBSplineVTKImageSegmentFilter::REGULAR_DIAGONAL);
            segment->Update();
#ifdef __PROFILE__
            Profiler.AddLogNormal("Segment Data", "swanIBSplineProfile", "End");
            segment->Profiler.save("/Users/deng/Desktop/NonUniform_IBS_Bunny.tif" + std::string(".1.log"));
            //segment->save(outName + std::string(".h5")); // Save the kernel matrix etc.
#endif
            
            
#ifdef __PROFILE__
            Profiler.AddLogNormal("Save Data", "swanIBSplineProfile", "Start");
#endif
            //Save to disk
            vtkSmartPointer<vtkImageData> result = vtkSmartPointer<vtkImageData>::New();
            result->DeepCopy(segment->GetOutput());
            result->SetSpacing(ospas);
            VTKImageSaveToTIF("/Users/deng/Desktop/NonUniform_IBS_Bunny.tif", result);
#ifdef __PROFILE__
            Profiler.AddLogNormal("Save Data", "swanIBSplineProfile", "End");
            Profiler.save("/Users/deng/Desktop/NonUniform_IBS_Bunny.tif" + std::string(".2.log"));
#endif
        };
        
        
/*==============================================================================================================================================*/
        void swanIBSplineVTKImageSegmentFilter_ExpSingleRun(std::string inName, std::string outName, IBSParameters para){
            swanProfileUtil Profiler;
            Profiler.setObjectName("swanIBSplineProfile.hpp:swanIBSplineVTKImageSegmentFilter_ExpSRun");
            Profiler.setDebugOFF();
            
#ifdef __PROFILE__
            Profiler.AddLogNormal("Read Data", "swanIBSplineProfile", "Start");
#endif
            vtkSmartPointer<vtkImageData> image = vtkSmartPointer<vtkImageData>::New();
            VTKImageLoadFromTIF(inName + std::string("Scr.tif"), image);
            
            vtkSmartPointer<vtkImageData> init = vtkSmartPointer<vtkImageData>::New();
            VTKImageLoadFromTIF(inName + std::string("Bin.tif"), init);
            
            int exts[6] = {0};
            image->GetExtent(exts);
            double ospas[3] = {0.0};
            image->GetSpacing(ospas);
            double nspas[3] = {1.0/(exts[1]-exts[0]), 1.0/(exts[3]-exts[2]), 1.0/(exts[5]-exts[4])};
            image->SetSpacing(nspas);
            init->SetSpacing(nspas);

            
            vtkSmartPointer<vtkImageCast> shape = vtkSmartPointer<vtkImageCast>::New();
            shape->SetInputData(init);
            shape->SetOutputScalarTypeToUnsignedChar();
            shape->Update();
            
#ifdef __PROFILE__
            Profiler.AddLogNormal("Read Data", "swanIBSplineProfile", "End");
#endif
            
            vtkSmartPointer<swanIBSplineVTKImageSegmentFilter> segment = vtkSmartPointer<swanIBSplineVTKImageSegmentFilter>::New();
            segment->setCoreHelperPath("/Users/deng/Desktop/IBSHelper");
#ifdef __PROFILE__
            segment->Profiler.setObjectName("swanIBSplineProfile.hpp:swanIBSplineVTKImageSegmentFilter_ExpSRun:segment");
            segment->Profiler.setDebugOFF();
#endif
            segment->SetInputData(0, image);
            segment->SetInputData(1, shape->GetOutput());
            segment->SetnItor(para.nItor);
            segment->SetNumberOfBSpline(para.nBSpline);
            segment->SetImageSampleRate(para.nSampleRate);
            segment->SetRegular(para.Regular);
            segment->SetisNonUniform(false);
            segment->Update();
#ifdef __PROFILE__
            Profiler.AddLogNormal("Segment Data", "swanIBSplineProfile", "End");
            segment->Profiler.save(outName + std::string(".1.log"));
            //segment->save(outName + std::string(".h5")); // Save the kernel matrix etc.
#endif
            
            
#ifdef __PROFILE__
            Profiler.AddLogNormal("Save Data", "swanIBSplineProfile", "Start");
#endif
            //Save to disk
            vtkSmartPointer<vtkImageData> result = vtkSmartPointer<vtkImageData>::New();
            result->DeepCopy(segment->GetOutput());
            result->SetSpacing(ospas);
            VTKImageSaveToTIF(outName, result);
#ifdef __PROFILE__
            Profiler.AddLogNormal("Save Data", "swanIBSplineProfile", "End");
            Profiler.save(outName + std::string(".2.log"));
#endif
        };
        
        
/*==============================================================================================================================================*/
        void swanIBSplineVTKImageSegmentFilter_ExpBatchRun(){
            std::string srcImgFolder = "/Users/deng/Desktop/Aorta/DAT/";
            std::string dstImgFolder = "/Users/deng/Desktop/Aorta/EXP/";
            std::vector<std::string> srcImgSample;
            
//            srcImgSample.push_back("VolumePred3.mat.tif");
//            srcImgSample.push_back("VolumePred6.mat.tif");
//            srcImgSample.push_back("VolumePred9.mat.tif");
//            srcImgSample.push_back("VolumePred12.mat.tif");
//            srcImgSample.push_back("VolumePred15.mat.tif");
//            srcImgSample.push_back("VolumePred21.mat.tif");
//            srcImgSample.push_back("VolumePred24.mat.tif");
//            srcImgSample.push_back("VolumePred27.mat.tif");
//            srcImgSample.push_back("VolumePred30.mat.tif");
//            srcImgSample.push_back("VolumePred34.mat.tif");
//            srcImgSample.push_back("VolumePred39.mat.tif");
//            srcImgSample.push_back("VolumePred43.mat.tif");
            
//            srcImgSample.push_back("VolumePred4.mat.tif");
//            srcImgSample.push_back("VolumePred7.mat.tif");
//            srcImgSample.push_back("VolumePred10.mat.tif");
//            srcImgSample.push_back("VolumePred13.mat.tif");
//            srcImgSample.push_back("VolumePred17.mat.tif");
//            srcImgSample.push_back("VolumePred22.mat.tif");
//            srcImgSample.push_back("VolumePred25.mat.tif");
//            srcImgSample.push_back("VolumePred28.mat.tif");
//            srcImgSample.push_back("VolumePred31.mat.tif");
//            srcImgSample.push_back("VolumePred35.mat.tif");
//            srcImgSample.push_back("VolumePred40.mat.tif");
//            srcImgSample.push_back("VolumePred44.mat.tif");
            
//            srcImgSample.push_back("VolumePred5.mat.tif");
//            srcImgSample.push_back("VolumePred8.mat.tif");
//            srcImgSample.push_back("VolumePred11.mat.tif");
//            srcImgSample.push_back("VolumePred14.mat.tif");
//            srcImgSample.push_back("VolumePred19.mat.tif");
//            srcImgSample.push_back("VolumePred23.mat.tif");
//            srcImgSample.push_back("VolumePred26.mat.tif");
//            srcImgSample.push_back("VolumePred29.mat.tif");
//            srcImgSample.push_back("VolumePred33.mat.tif");
//            srcImgSample.push_back("VolumePred36.mat.tif");
//            srcImgSample.push_back("VolumePred41.mat.tif");
//            srcImgSample.push_back("VolumePred45.mat.tif");
            
//            srcImgSample.push_back("Bunny.tif");
//            srcImgSample.push_back("DNAX4.tif");
//            srcImgSample.push_back("Dragon.tif");
//            srcImgSample.push_back("FloorLamp.tif");
//            srcImgSample.push_back("Killeroo.tif");
//            srcImgSample.push_back("LightDiskShroud.tif");
//            srcImgSample.push_back("LightRectShroud.tif");
//            srcImgSample.push_back("Mitsuba.tif");
//            srcImgSample.push_back("MitsubaSphere.tif");
//            srcImgSample.push_back("MoleculaX4.tif");
//            srcImgSample.push_back("NavalstringX4.tif");
//            srcImgSample.push_back("Pancakes.tif");
//            srcImgSample.push_back("Piggy.tif");
//            srcImgSample.push_back("Sphere.tif");
//            srcImgSample.push_back("StarSix.tif");
//            srcImgSample.push_back("Teapot.tif");
//            srcImgSample.push_back("Vase.tif");
//            srcImgSample.push_back("WineGlass.tif");
            
            srcImgSample.push_back("Volume36");
            
            IBSParameters para;
            para.nItor = 40;
            //para.Regular = swanIBSplineVTKImageSegmentFilter::REGULAR_TENSION;
            para.Regular = swanIBSplineVTKImageSegmentFilter::REGULAR_DIAGONAL;

            
            for(int k=0; k<srcImgSample.size(); k++){ //image sample loop
                char bufferFolder[255] = {0};
                char bufferFile[255] = {0};
                sprintf(bufferFolder, "%s%s.Results/", dstImgFolder.c_str(), srcImgSample[k].c_str());
                DIR *pDir = NULL;
                pDir = opendir(bufferFolder);
                if(pDir != NULL){
                    std::cout<<"Destination folder is exist, Avoid."<<std::endl;
                    continue;
                }
                else{
                    mkdir(bufferFolder, 0777);
                    para.nBSpline = 33;
                    para.nSampleRate = 3;
//                    for(int i=0; i<8; i++){ //nBSpline loop
//                        para.nSampleRate = 2;
//                        for(int j=0; j<5; j++){ //nSampleRate loop
//                            sprintf(bufferFile, "%sBSpline%d.Sample%d.tif", bufferFolder, para.nBSpline, para.nSampleRate);
//                            std::cout<<"Process==> Src:"<<std::string(srcImgFolder + srcImgSample[k])<<"; Dst:"<<std::string(bufferFile)<<"; ";
//                            std::cout<<"With nBSpline:"<<para.nBSpline<<"; nSampleRate:"<<para.nSampleRate<<";"<<std::endl;
//                            
//                            swanIBSplineVTKImageSegmentFilter_ExpSingleRun(std::string(srcImgFolder + srcImgSample[k]),
//                                                                           std::string(bufferFile),
//                                                                           para);
//                            sleep(3);
//                            para.nSampleRate += 1;
//                        }
//                        para.nBSpline += 5;
//                    }
                    sprintf(bufferFile, "%sBSpline%d.Sample%d.tif", bufferFolder, para.nBSpline, para.nSampleRate);
                    swanIBSplineVTKImageSegmentFilter_ExpSingleRun(std::string(srcImgFolder + srcImgSample[k]), std::string(bufferFile), para);
                }
            }
        };
        
    }
    
    
/*==============================================================================================================================================*/
}

#endif
