//
//  swanIBSplineVTKImageSegmentFilter.h
//  iSSwan
//
//  Created by Jingjing Deng on 09/03/2015.
//  Copyright (c) 2015 J. Deng. All rights reserved.
//

#ifndef __iSSwan__swanIBSplineVTKImageSegmentFilter__
#define __iSSwan__swanIBSplineVTKImageSegmentFilter__

#include "swanIBSpline3DHelper.h"
#include "swanProfileUtil.h"
#include "swanType.h"

#include <stdio.h>
#include <vtkImageAlgorithm.h>
#include <vtkImageCast.h>
#include <itkTIFFImageIO.h>
#include <vtkSmartPointer.h>

#include <eigen3/Eigen/Core>
#include <eigen3/Eigen/SparseCore>
#include <eigen3/Eigen/Sparse>
#include <eigen3/Eigen/SparseQR>
#include <eigen3/Eigen/SparseLU>
#include <eigen3/Eigen/SparseCholesky>
#include <eigen3/Eigen/IterativeLinearSolvers>
#include <eigen3/Eigen/UmfPackSupport>
#include <eigen3/Eigen/OrderingMethods>

#include <string>

namespace csvision {
    
    class swanIBSplineVTKImageSegmentFilter : public vtkImageAlgorithm
    {
    protected:
        swanIBSplineVTKImageSegmentFilter();
        ~swanIBSplineVTKImageSegmentFilter();
        virtual int FillInputPortInformation(int port, vtkInformation* info);
        virtual int RequestData(vtkInformation* request, vtkInformationVector** inputVector, vtkInformationVector* outputVector);
        
    private:
        swanIBSplineVTKImageSegmentFilter(const swanIBSplineVTKImageSegmentFilter&);
        bool operator=(const swanIBSplineVTKImageSegmentFilter&);
        
    public:
        static swanIBSplineVTKImageSegmentFilter* New();
        vtkTypeMacro(swanIBSplineVTKImageSegmentFilter, vtkImageAlgorithm);
        void PrintSelf(std::ostream, vtkIndent);
        void save(std::string fn);
        void setCoreHelperPath(std::string fp);
        void SaveToTIF(std::string fn, vtkSmartPointer<vtkImageData> img);
        
    protected:
        int         NumberOfBSpline;
        double      RegularWeight;
        int  Regular;
        
        int     nItor;
        double  epsilonH;
        double  epsilonD;
        double  tau;
        double  ImgIntensityMax;
        double  ImgIntensityMin;
        int     FlowVelc;
        int     ImageSampleRate;
        bool    isNonUniform;
        std::vector<int> DensityX;
        std::vector<int> DensityY;
        std::vector<int> DensityZ;
        
        csvision::swanIBSpline3DHelper Core;
        
    public:
        
        void SetDensity(int* DX, int* DY, int* DZ);
        vtkSetMacro(NumberOfBSpline, int);
        vtkGetMacro(NumberOfBSpline, int);
        vtkSetMacro(RegularWeight, double);
        vtkGetMacro(RegularWeight, double);
        vtkSetMacro(Regular, int);
        vtkGetMacro(Regular, int);
        vtkSetMacro(epsilonH, double);
        vtkGetMacro(epsilonH, double);
        vtkSetMacro(epsilonD, double);
        vtkGetMacro(epsilonD, double);
        vtkSetMacro(tau, double);
        vtkGetMacro(tau, double);
        vtkSetMacro(nItor, int);
        vtkGetMacro(nItor, int);
        vtkSetMacro(FlowVelc, int);
        vtkGetMacro(FlowVelc, int);
        vtkSetMacro(ImageSampleRate, int);
        vtkGetMacro(ImageSampleRate, int);
        vtkSetMacro(isNonUniform, bool);
        vtkGetMacro(isNonUniform, bool);

        
        static const int FLOW_CONSTANT;
        static const int FLOW_CHANVESE;
        
        static const int REGULAR_NONE;
        static const int REGULAR_DIAGONAL;
        static const int REGULAR_TENSION;
        
        static double RegularDirac(double X, double eps);
        static double RegularHeavi(double X, double eps);
        
#ifdef __PROFILE__
        swanProfileUtil Profiler;
#endif
        
    };
}
#endif /* defined(__iSSwan__swanIBSplineVTKImageSegmentFilter__) */
