//
//  swanIBSpline3DHelper.cpp
//  iSSwan
//
//  Created by Jingjing Deng on 24/04/2015.
//
//

#include "swanIBSpline3DHelper.h"

#include <iostream>
#include <unistd.h>
#include <dirent.h>
#include <sys/stat.h>
#include <sys/types.h>

#include <tbb/tbb.h>
#include <eigen3/Eigen/Core>
#include <eigen3/Eigen/SparseCore>
#include <eigen3/Eigen/Sparse>
#include <eigen3/Eigen/SparseQR>
#include <eigen3/Eigen/SparseLU>
#include <eigen3/Eigen/SparseCholesky>
#include <eigen3/Eigen/IterativeLinearSolvers>
#include <eigen3/Eigen/UmfPackSupport>
#include <eigen3/Eigen/OrderingMethods>


using namespace csvision;

USERReal64 const swanIBSpline3DHelper::BlendBasis[4][4] = {{-1.0/6,  3.0/6, -3.0/6,  1.0/6},
                                                           { 3.0/6, -6.0/6,  3.0/6,  0.0/6},
                                                           {-3.0/6,  0.0/6,  3.0/6,  0.0/6},
                                                           { 1.0/6,  4.0/6,  1.0/6,  0.0/6}};

USERReal64 const swanIBSpline3DHelper::BlendDriv1[4][4] = {{ 0.0/6,  0.0/6,  0.0/6,  0.0/6},
                                                           {-3.0/6,  9.0/6, -9.0/6,  3.0/6},
                                                           { 6.0/6,-12.0/6,  6.0/6,  0.0/6},
                                                           {-3.0/6,  0.0/6,  3.0/6,  0.0/6}};

USERReal64 const swanIBSpline3DHelper::BlendDriv2[4][4] = {{ 0.0/6,  0.0/6,  0.0/6,  0.0/6},
                                                           { 0.0/6,  0.0/6,  0.0/6,  0.0/6},
                                                           {-6.0/6, 18.0/6,-18.0/6,  6.0/6},
                                                           { 6.0/6,-12.0/6,  6.0/6,  0.0/6}};

const int swanIBSpline3DHelper::REGULAR_NONE  = 0;
const int swanIBSpline3DHelper::REGULAR_DIAGONAL = 1;
const int swanIBSpline3DHelper::REGULAR_TENSION  = 2;

const int swanIBSpline3DHelper::SOLVER_UMFPACK  = 1;
const int swanIBSpline3DHelper::SOLVER_VIENNACL = 2;

swanIBSpline3DHelper::swanIBSpline3DHelper()
{
    this->NumberOfSpline = 20;
    this->Degree = 3;
    this->Regular = swanIBSpline3DHelper::REGULAR_TENSION;
    this->RegularWeight = 1.0;
    this->Coeff.setZero();
    this->ControlPts.clear();
    this->ControlFnv.setZero();
    this->HelperPath = "";
    this->ResidualError = 0.0;
    this->isNonUniform = false;
    
    for(int i = 0; i < 4; i++){
        for (int j = 0; j < 4; j++) {
            B.coeffRef(i, j)=BlendBasis[i][j];
        }
    }
    
    for(int i = 0; i < 4; i++){
        for (int j = 0; j < 4; j++) {
            BDr1.coeffRef(i, j)=BlendDriv1[i][j];
        }
    }
    
    for(int i = 0; i < 4; i++){
        for (int j = 0; j < 4; j++) {
            BDr2.coeffRef(i, j)=BlendDriv2[i][j];
        }
    }
    
    Eigen::initParallel();
}

swanIBSpline3DHelper::~swanIBSpline3DHelper()
{
    
}

NumberUInteger32 swanIBSpline3DHelper::GetNumberOfSpline()
{
    return this->NumberOfSpline;
}

void swanIBSpline3DHelper::SetNumberOfSpline(NumberUInteger32 xyz)
{
    this->NumberOfSpline = xyz;
}

void swanIBSpline3DHelper::SetRegular(int r)
{
    this->Regular = r;
}

int swanIBSpline3DHelper::GetRegular()
{
    return this->Regular;
}

void swanIBSpline3DHelper::SetRegularWeight(USERReal64 w)
{
    this->RegularWeight = w;
}

USERReal64 swanIBSpline3DHelper::GetRegularWeight()
{
    return this->RegularWeight;
}

void swanIBSpline3DHelper::SetCoeff(ColVectorX C)
{
    this->Coeff = C;
}

ColVectorX swanIBSpline3DHelper::GetCoeff()
{
    return this->Coeff;
}

bool swanIBSpline3DHelper::GetisNonUniform()
{
    return isNonUniform;
}

void swanIBSpline3DHelper::SetisNonUniform(bool is)
{
    isNonUniform = is;
}

void swanIBSpline3DHelper::SetDensity(std::vector<int> DX, std::vector<int> DY, std::vector<int> DZ)
{
    DensityX = DX;
    DensityY = DY;
    DensityZ = DZ;
}

void swanIBSpline3DHelper::Kernelize(Point3DSet Pts)
{
    this->ControlPts = Pts;
    this->BasisesMatrix(Pts);
    this->RegularMatrix();

    if(this->Regular == swanIBSpline3DHelper::REGULAR_TENSION){
        K = M.transpose()*M + RegularWeight*H;
    }
    else if(this->Regular == swanIBSpline3DHelper::REGULAR_DIAGONAL) {
        K = M.transpose()*M + RegularWeight*H;
    }
    else if(this->Regular == swanIBSpline3DHelper::REGULAR_NONE) {
        K = M.transpose()*M;
    }
    //std::cout<<"K Matrix:"<<(long)K.nonZeros()<<"/"<<(long)K.size()<<"="<<(double)K.nonZeros()/(long)K.size()<<std::endl;
}

void swanIBSpline3DHelper::Factorize()
{
    UmfPackLUSolver.analyzePattern(K);
    UmfPackLUSolver.factorize(K);
}

ColVectorX swanIBSpline3DHelper::GeneralSolve(ColVectorX V)
{
    ColVectorX C = UmfPackLUSolver.solve(M.transpose()*V);
    return C;
}

ColVectorX swanIBSpline3DHelper::Approximate(ColVectorX V)
{
    this->ControlFnv = V;
    Coeff = UmfPackLUSolver.solve(M.transpose()*V);
    
    // Compute the residual error
    ColVectorX AP = Interpolate(ControlPts);
    ColVectorX RE = AP - V;
    ColVectorX ARE = RE.cwiseAbs();
    this->ResidualError = ARE.sum();
    
    return Coeff;
}

ColVectorX swanIBSpline3DHelper::Interpolate(Point3DSet Pts)
{
    ColVectorX F;
    F.resize(Pts.size(), 1);
    double Step = 1.0/(this->NumberOfSpline-3);
    
    // TBB Parallel For Loop
    tbb::parallel_for(0, (int)Pts.size(), [&](int idx) {
        Point3D pt = Pts[idx];
        double FuncValue = 0.0;
        
        if(isNonUniform == false){
            int indexX = floor(pt.X/Step)+1;
            int indexY = floor(pt.Y/Step)+1;
            int indexZ = floor(pt.Z/Step)+1;
            
            double paraU = (pt.X/Step)-indexX+1;
            double paraV = (pt.Y/Step)-indexY+1;
            double paraW = (pt.Z/Step)-indexZ+1;
            
            RowVector4 U;
            RowVector4 V;
            RowVector4 W;
            U<<pow(paraU,3), pow(paraU,2), paraU, 1;
            V<<pow(paraV,3), pow(paraV,2), paraV, 1;
            W<<pow(paraW,3), pow(paraW,2), paraW, 1;
            
            RowVector4 UB = U*B;
            RowVector4 VB = V*B;
            RowVector4 WB = W*B;
            
            for(int i = 0; i <=this->Degree; i++){
                for(int j = 0; j <=this->Degree; j++){
                    for(int k = 0; k <=this->Degree; k++){
                        if((indexX+i-1>=0 && indexX+i-1<this->NumberOfSpline) &&
                           (indexY+j-1>=0 && indexY+j-1<this->NumberOfSpline) &&
                           (indexZ+k-1>=0 && indexZ+k-1<this->NumberOfSpline)){
                            int index = (indexX+i-1) * this->NumberOfSpline * this->NumberOfSpline +
                                        (indexY+j-1) * this->NumberOfSpline +
                                        (indexZ+k) - 1;
                            FuncValue += UB(i)*VB(j)*WB(k)*Coeff(index);
                        }
                    }
                }
            }
            F(idx) = FuncValue;
        }
        else{
            //Tempoary solution, could be much fast using smart way
            //X direction
            double GapUX = floor(double(DensityX[NumberOfSpline-4])/(NumberOfSpline-3));
            int indexX = 1;
            for(int xi = 0; xi<NumberOfSpline-3; xi++){
                if(pt.X>double(DensityX[xi])/DensityX[NumberOfSpline-4]){
                    indexX++;
                    continue;
                }
                else{
                    break;
                }
            }
            int GapX = 0;
            double paraU = 0.0;
            if(indexX == 1){
                GapX = DensityX[0];
                paraU = (pt.X/GapX)*DensityX[NumberOfSpline-4];
            }
            else{
                GapX = DensityX[indexX-1]-DensityX[indexX-2]+1;
                paraU = ((pt.X-(double(DensityX.at(indexX-2))/DensityX.at(NumberOfSpline-4)))/GapX)*DensityX.at(NumberOfSpline-4);
            }
            
            //Y direction
            double GapUY = floor(double(DensityY[NumberOfSpline-4])/(NumberOfSpline-3));
            int indexY = 1;
            for(int yi = 0; yi<NumberOfSpline-3; yi++){
                if(pt.Y>double(DensityY[yi])/DensityY[NumberOfSpline-4]){
                    indexY++;
                    continue;
                }
                else{
                    break;
                }
            }
            int GapY = 0;
            double paraV = 0.0;
            if(indexY == 1){
                GapY = DensityY[0];
                paraV = (pt.Y/GapY)*DensityY[NumberOfSpline-4];
            }
            else{
                GapY = DensityY[indexY-1]-DensityY[indexY-2]+1;
                paraV = ((pt.Y-(double(DensityY.at(indexY-2))/DensityY.at(NumberOfSpline-4)))/GapY)*DensityY.at(NumberOfSpline-4);
            }
            
            //Z direction
            double GapUZ = floor(double(DensityZ[NumberOfSpline-4])/(NumberOfSpline-3));
            int indexZ = 1;
            for(int zi = 0; zi<NumberOfSpline-3; zi++){
                if(pt.Z>(double(DensityZ[zi])/DensityZ[NumberOfSpline-4])){
                    indexZ++;
                    continue;
                }
                else{
                    break;
                }
            }
            int GapZ = 0;
            double paraW = 0.0;
            if(indexZ == 1){
                GapZ = DensityZ.at(0);
                paraW = (pt.Z/GapZ)*DensityZ[NumberOfSpline-4];
            }
            else{
                GapZ = DensityZ.at(indexZ-1)-DensityZ.at(indexZ-2)+1;
                paraW = ((pt.Z-(double(DensityZ.at(indexZ-2))/DensityZ.at(NumberOfSpline-4)))/GapZ)*DensityZ.at(NumberOfSpline-4);
            }
            
            
            RowVector4 U;
            RowVector4 V;
            RowVector4 W;
            U<<pow(paraU,3), pow(paraU,2), paraU, 1;
            V<<pow(paraV,3), pow(paraV,2), paraV, 1;
            W<<pow(paraW,3), pow(paraW,2), paraW, 1;
            
            double factorU = ((double)GapX/GapUX);
            double factorV = ((double)GapY/GapUY);
            double factorW = ((double)GapZ/GapUZ);
            
            RowVector4 UB = U*B;
            RowVector4 VB = V*B;
            RowVector4 WB = W*B;
            
            for(int i = 0; i <=this->Degree; i++){
                for(int j = 0; j <=this->Degree; j++){
                    for(int k = 0; k <=this->Degree; k++){
                        if((indexX+i-1>=0 && indexX+i-1<this->NumberOfSpline) &&
                           (indexY+j-1>=0 && indexY+j-1<this->NumberOfSpline) &&
                           (indexZ+k-1>=0 && indexZ+k-1<this->NumberOfSpline)){
                            int index = (indexX+i-1) * this->NumberOfSpline * this->NumberOfSpline +
                            (indexY+j-1) * this->NumberOfSpline +
                            (indexZ+k) - 1;
                            FuncValue += UB(i)*VB(j)*WB(k)*Coeff(index);
                        }
                    }
                }
            }
            F(idx) = FuncValue;
        }
    });

    return F;
}

void swanIBSpline3DHelper::SetHelperPath(std::string hp)
{
    HelperPath = hp;
}

std::string swanIBSpline3DHelper::GetHelperPath()
{
    return HelperPath;
}


/*---------------------------------------------------------------------------------------------------------------------------*/
/*---------------------------------------------------------------------------------------------------------------------------*/

void swanIBSpline3DHelper::BasisesMatrix(Point3DSet Pts)
{
    M.resize((int)Pts.size(), this->NumberOfSpline * this->NumberOfSpline * this->NumberOfSpline);
    M.setZero();
    
    /* Single Thread Version */
    if(isNonUniform == false){
        double Step = 1.0/(NumberOfSpline-3);
        std::vector<Triplet> tripletList;
        tripletList.reserve(floor(M.rows()*0.02*M.cols()));
        
        for(int idx = 0; idx < Pts.size(); idx++){
            Point3D pt = Pts[idx];
            
            int indexX = floor(pt.X/Step)+1;
            int indexY = floor(pt.Y/Step)+1;
            int indexZ = floor(pt.Z/Step)+1;
            
            double paraU = (pt.X/Step)-indexX+1;
            double paraV = (pt.Y/Step)-indexY+1;
            double paraW = (pt.Z/Step)-indexZ+1;
            
            RowVector4 U;
            RowVector4 V;
            RowVector4 W;
            U<<pow(paraU,3), pow(paraU,2), paraU, 1;
            V<<pow(paraV,3), pow(paraV,2), paraV, 1;
            W<<pow(paraW,3), pow(paraW,2), paraW, 1;
            
            RowVector4 UB = U*B;
            RowVector4 VB = V*B;
            RowVector4 WB = W*B;
            
            for(int i = 0; i <=Degree; i++){
                for(int j = 0; j <=Degree; j++){
                    for(int k = 0; k <=Degree; k++){
                        if((indexX+i-1>=0 && indexX+i-1<NumberOfSpline) &&
                           (indexY+j-1>=0 && indexY+j-1<NumberOfSpline) &&
                           (indexZ+k-1>=0 && indexZ+k-1<NumberOfSpline)){
                            int index = (indexX+i-1) * NumberOfSpline * NumberOfSpline +
                                        (indexY+j-1) * NumberOfSpline +
                                        (indexZ+k) - 1;
                            double v = UB.coeff(i)*VB.coeff(j)*WB.coeff(k);
                            if(v > std::numeric_limits<double>::epsilon() || v < -std::numeric_limits<double>::epsilon())
                                tripletList.push_back(Triplet((int)idx, index, v));
                        }
                    }
                }
            }
        }
        M.setFromTriplets(tripletList.begin(), tripletList.end());
    }
    else{
        std::vector<Triplet> tripletList;
        tripletList.reserve(floor(M.rows()*0.02*M.cols()));
        
        for(int idx = 0; idx < Pts.size(); idx++){
            Point3D pt = Pts[idx];
            
            //Tempoary solution, could be much fast using smart way
            //X direction
            double GapUX = floor(double(DensityX[NumberOfSpline-4])/(NumberOfSpline-3));
            int indexX = 1;
            for(int xi = 0; xi<NumberOfSpline-3; xi++){
                if(pt.X>double(DensityX[xi])/DensityX[NumberOfSpline-4]){
                    indexX++;
                    continue;
                }
                else{
                    break;
                }
            }
            int GapX = 0;
            double paraU = 0.0;
            if(indexX == 1){
                GapX = DensityX[0];
                paraU = (pt.X/GapX)*DensityX[NumberOfSpline-4];
            }
            else{
                GapX = DensityX[indexX-1]-DensityX[indexX-2]+1;
                paraU = ((pt.X-(double(DensityX.at(indexX-2))/DensityX.at(NumberOfSpline-4)))/GapX)*DensityX.at(NumberOfSpline-4);
            }
            
            //Y direction
            double GapUY = floor(double(DensityY[NumberOfSpline-4])/(NumberOfSpline-3));
            int indexY = 1;
            for(int yi = 0; yi<NumberOfSpline-3; yi++){
                if(pt.Y>double(DensityY[yi])/DensityY[NumberOfSpline-4]){
                    indexY++;
                    continue;
                }
                else{
                    break;
                }
            }
            int GapY = 0;
            double paraV = 0.0;
            if(indexY == 1){
                GapY = DensityY[0];
                paraV = (pt.Y/GapY)*DensityY[NumberOfSpline-4];
            }
            else{
                GapY = DensityY[indexY-1]-DensityY[indexY-2]+1;
                paraV = ((pt.Y-(double(DensityY.at(indexY-2))/DensityY.at(NumberOfSpline-4)))/GapY)*DensityY.at(NumberOfSpline-4);
            }
            
            //Z direction
            double GapUZ = floor(double(DensityZ[NumberOfSpline-4])/(NumberOfSpline-3));
            int indexZ = 1;
            for(int zi = 0; zi<NumberOfSpline-3; zi++){
                if(pt.Z>(double(DensityZ[zi])/DensityZ[NumberOfSpline-4])){
                    indexZ++;
                    continue;
                }
                else{
                    break;
                }
            }
            int GapZ = 0;
            double paraW = 0.0;
            if(indexZ == 1){
                GapZ = DensityZ.at(0);
                paraW = (pt.Z/GapZ)*DensityZ[NumberOfSpline-4];
            }
            else{
                GapZ = DensityZ.at(indexZ-1)-DensityZ.at(indexZ-2)+1;
                paraW = ((pt.Z-(double(DensityZ.at(indexZ-2))/DensityZ.at(NumberOfSpline-4)))/GapZ)*DensityZ.at(NumberOfSpline-4);
            }
            
            
            RowVector4 U;
            RowVector4 V;
            RowVector4 W;
            U<<pow(paraU,3), pow(paraU,2), paraU, 1;
            V<<pow(paraV,3), pow(paraV,2), paraV, 1;
            W<<pow(paraW,3), pow(paraW,2), paraW, 1;
            
            double factorU = ((double)GapX/GapUX);
            double factorV = ((double)GapY/GapUY);
            double factorW = ((double)GapZ/GapUZ);
            
            RowVector4 UB = U*B;
            RowVector4 VB = V*B;
            RowVector4 WB = W*B;
            
            for(int i = 0; i <=Degree; i++){
                for(int j = 0; j <=Degree; j++){
                    for(int k = 0; k <=Degree; k++){
                        if((indexX+i-1>=0 && indexX+i-1<NumberOfSpline) &&
                           (indexY+j-1>=0 && indexY+j-1<NumberOfSpline) &&
                           (indexZ+k-1>=0 && indexZ+k-1<NumberOfSpline)){
                            int index = (indexX+i-1) * NumberOfSpline * NumberOfSpline +
                            (indexY+j-1) * NumberOfSpline +
                            (indexZ+k) - 1;
                            double v = UB.coeff(i)*VB.coeff(j)*WB.coeff(k);
                            if(v > std::numeric_limits<double>::epsilon() || v < -std::numeric_limits<double>::epsilon())
                                tripletList.push_back(Triplet((int)idx, index, v));
                        }
                    }
                }
            }
        }
        M.setFromTriplets(tripletList.begin(), tripletList.end());

    }
    //std::cout<<"M Matrix:"<<(long)M.nonZeros()<<"/"<<(long)M.size()<<"="<<(double)M.nonZeros()/(long)M.size()<<std::endl;
}

void swanIBSpline3DHelper::RegularMatrix()
{
    int Dim = this->NumberOfSpline * this->NumberOfSpline * this->NumberOfSpline;
    char buffer[255] = {0};
    
    bool isLoaded = false;
    
    H.resize(Dim, Dim);
    H.setZero();
    
    if(HelperPath != ""){
        sprintf(buffer, "%s/RMatrix%d.h5", HelperPath.c_str(), this->NumberOfSpline);
        struct stat exist;
        if(stat(buffer, &exist) == 0){
            H5::H5File fMatrix(buffer, H5F_ACC_RDONLY);
            EigenHDF5::load_sparse(fMatrix, "H", H);
            std::cout<<"Load Regular Matrix from:"<<buffer<<std::endl;
            fMatrix.close();
            isLoaded = true;
        }
    }
    
    if(this->Regular == swanIBSpline3DHelper::REGULAR_DIAGONAL){
        H.setIdentity();
    }
    else if(this->Regular == swanIBSpline3DHelper::REGULAR_TENSION && !isLoaded){
        SqrMatrixX Pi0;
        SqrMatrixX Pi1;
        SqrMatrixX Pi2;
        
        BasisConv(Pi0, Pi1, Pi2);
        
        H.setZero();
        
        std::vector<Triplet> tripletList;
        tripletList.reserve(floor(pow(NumberOfSpline * NumberOfSpline * NumberOfSpline,2) * 0.04));
        
        for(int ik = 1; ik <= NumberOfSpline; ik++){
            for(int jk = 1; jk <= NumberOfSpline; jk++){
                for(int kk = 1; kk <= NumberOfSpline; kk++){
                    int k = (int)(ik-1)*NumberOfSpline*NumberOfSpline + (jk-1)*NumberOfSpline + kk;
                    
                    for(int il = 1; il <= NumberOfSpline; il++){
                        for(int jl = 1; jl <= NumberOfSpline; jl++){
                            for(int kl = 1; kl <= NumberOfSpline; kl++){
                                int l = (il-1)*NumberOfSpline*NumberOfSpline + (jl-1)*NumberOfSpline + kl;
                                
                                double v = Pi2.coeff(ik-1,il-1) * Pi0.coeff(jk-1,jl-1) * Pi0.coeff(kk-1,kl-1) +
                                           2*Pi1.coeff(ik-1,il-1) * Pi1.coeff(jk-1,jl-1) * Pi0.coeff(kk-1,kl-1) +
                                           Pi0.coeff(ik-1,il-1) * Pi2.coeff(jk-1,jl-1) * Pi0.coeff(kk-1,kl-1) +
                                           2*Pi1.coeff(ik-1,il-1) * Pi0.coeff(jk-1,jl-1) * Pi1.coeff(kk-1,kl-1) +
                                           2*Pi0.coeff(ik-1,il-1) * Pi1.coeff(jk-1,jl-1) * Pi1.coeff(kk-1,kl-1) +
                                           Pi0.coeff(ik-1,il-1) * Pi0.coeff(jk-1,jl-1) * Pi2.coeff(kk-1,kl-1);
                                
                                if(v > std::numeric_limits<double>::epsilon() || v < -std::numeric_limits<double>::epsilon())
                                    tripletList.push_back(Triplet(k-1,l-1,v));
                            }
                        }
                    }
                    
                }
            }
        }
        H.setFromTriplets(tripletList.begin(), tripletList.end());
        
        if(HelperPath != ""){
            sprintf(buffer, "%s/RMatrix%d.h5", HelperPath.c_str(), this->NumberOfSpline);
            struct stat exist;
            if(stat(buffer, &exist) != 0){
                H5::H5File fMatrix(buffer, H5F_ACC_TRUNC);
                EigenHDF5::save_sparse(fMatrix, "H", H);
                std::cout<<"Save Regular Matrix To:"<<buffer<<std::endl;
                fMatrix.close();
            }
        }
    }
    
    //std::cout<<"H Matrix:"<<(long)H.nonZeros()<<"/"<<(long)H.size()<<"="<<(double)H.nonZeros()/(long)H.size()<<std::endl;
}

inline void swanIBSpline3DHelper::BasisConv(SqrMatrixX& P0, SqrMatrixX& P1, SqrMatrixX& P2)
{
    SqrMatrix4 pp0;
    InterMult(B, B, pp0);
    SqrMatrix4 pp1;
    InterMult(BDr1, BDr1, pp1);
    SqrMatrix4 pp2;
    InterMult(BDr2, BDr2, pp2);
    
    P0.resize(this->NumberOfSpline, this->NumberOfSpline);
    P0.setZero();
    P1.resize(this->NumberOfSpline, this->NumberOfSpline);
    P1.setZero();
    P2.resize(this->NumberOfSpline, this->NumberOfSpline);
    P2.setZero();
    
    double StepX = double(1)/(this->NumberOfSpline-3);
    
    for(int i = 1; i <= this->NumberOfSpline-3; i++){
        for(int j = 0; j <=3; j++){
            for(int k = 0; k <= 3; k++){
                P0(i+j-1, i+k-1) += pp0(j,k)*StepX;
                P1(i+j-1, i+k-1) += pp1(j,k)*StepX;
                P2(i+j-1, i+k-1) += pp2(j,k)*StepX;
            }
        }
    }
}

inline void swanIBSpline3DHelper::InterMult(const SqrMatrix4& m1, const SqrMatrix4& m2, SqrMatrix4& m)
{
    m.setZero();
    for(int i = 0; i < 4; i++){
        for(int j = 0; j < 4; j++){
            ColVector7 w;
            w.setZero();
            ColVector4 a = m1.col(i);
            ColVector4 b = m2.col(j);
            MultColVect(a, b, w);
            
            double sum = 0.0;
            for(int k = 0; k < 7; k++){
                sum += w(k)/(7-k);
            }
            m(i,j) = sum;
        }
    }
}

inline void swanIBSpline3DHelper::MultColVect(const ColVector4& v1, const ColVector4& v2, ColVector7& v)
{
    v.setZero();
    for(int i = 1; i <= 4; i++){
        for(int j = 1; j <= 4; j++){
            v(i+j-2) += v1(i-1)*v2(j-1);
        }
    }
}
