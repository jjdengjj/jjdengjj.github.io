//
//  swanIBSpline3DHelper.h
//  iSSwan
//
//  Created by Jingjing Deng on 24/04/2015.
//
//

#ifndef __iSSwan__swanBSplineHelper__
#define __iSSwan__swanBSplineHelper__

#include <stdio.h>

#include <tbb/tbb.h>
#include <tbb/mutex.h>

#include "swanType.h"
#include "swanConfig.h"
#include "eigen3-hdf5.hpp"
#include "eigen3-hdf5-sparse.hpp"
#include "swanProfileUtil.h"

namespace csvision {
    
    class swanIBSpline3DHelper
    {
    public:
        swanIBSpline3DHelper();
        ~swanIBSpline3DHelper();
        
    public:
        static const USERReal64 BlendBasis[4][4];
        static const USERReal64 BlendDriv1[4][4];
        static const USERReal64 BlendDriv2[4][4];
        
        static const int REGULAR_NONE;
        static const int REGULAR_DIAGONAL;
        static const int REGULAR_TENSION;
        
        static const int SOLVER_UMFPACK;
        static const int SOLVER_VIENNACL;
        
        std::string         HelperPath;
        
        void                SetHelperPath(std::string hp);
        std::string         GetHelperPath();
        void                SetNumberOfSpline(NumberUInteger32 xyz);
        NumberUInteger32    GetNumberOfSpline();
        void                SetRegular(int r);
        int                 GetRegular();
        void                SetRegularWeight(USERReal64 w);
        USERReal64          GetRegularWeight();
        void                SetCoeff(ColVectorX C);
        ColVectorX          GetCoeff();
        bool                GetisNonUniform();
        void                SetisNonUniform(bool is);
        void                SetDensity(std::vector<int> DX, std::vector<int> DY, std::vector<int> DZ);
        
        void                Kernelize(Point3DSet Pts);
        void                Factorize();
        ColVectorX          Approximate(ColVectorX V);
        ColVectorX          Interpolate(Point3DSet Pts);
        ColVectorX          GeneralSolve(ColVectorX V);

        NumberUInteger32 NumberOfSpline;
        NumberUInteger32 Degree;
        int              Regular;
        USERReal64       RegularWeight;
        USERReal64       ResidualError;
        
        SqrMatrix4 B;
        SqrMatrix4 BDr1;
        SqrMatrix4 BDr2;
        
        SparseMat   K;
        SparseMat   M;
        SparseMat   H;
        ColVectorX  Coeff;
        Point3DSet  ControlPts;
        ColVectorX  ControlFnv;
        SparseSolver_UmfPackLU UmfPackLUSolver;
        SparseSolver_SimplicialLLT SimplicialLLTSolver;
        
        bool isNonUniform;
        std::vector<int> DensityX;
        std::vector<int> DensityY;
        std::vector<int> DensityZ;
        
        void BasisesMatrix(Point3DSet Pts);
        void RegularMatrix();
        void BasisConv(SqrMatrixX& P0, SqrMatrixX& P1, SqrMatrixX& P2);
        void InterMult(const SqrMatrix4& m1, const SqrMatrix4& m2, SqrMatrix4& m);
        void MultColVect(const ColVector4& v1, const ColVector4& v2, ColVector7& v);
    };
    
}


#endif /* defined(__iSSwan__swanBSplineHelper__) */
