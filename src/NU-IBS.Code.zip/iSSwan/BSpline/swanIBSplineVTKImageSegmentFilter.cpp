//
//  swanIBSplineVTKImageSegmentFilter.cpp
//  iSSwan
//
//  Created by Jingjing Deng on 09/03/2015.
//  Copyright (c) 2015 J. Deng. All rights reserved.
//

#include "swanIBSplineVTKImageSegmentFilter.h"
#include "swanVTKImageGridSamplingFilter.h"

#include <vtkObjectFactory.h>
#include <vtkInformation.h>
#include <vtkInformationVector.h>
#include <vtkSmartPointer.h>
#include <vtkPointSet.h>
#include <vtkPointData.h>
#include <vtkDataArray.h>
#include <vtkDoubleArray.h>
#include <vtkArrayData.h>
#include <vtkDenseArray.h>
#include <vtkArray.h>
#include <vtkImageData.h>
#include <vtkPolyData.h>
#include <vtkPoints.h>
#include <vtkXMLImageDataWriter.h>
#include <vtkTIFFWriter.h>
#include <vtkStreamingDemandDrivenPipeline.h>

#include <itkImage.h>
#include <itkSignedMaurerDistanceMapImageFilter.h>
#include <itkVTKImageToImageFilter.h>
#include <itkImageToVTKImageFilter.h>
#include <itkImageFileWriter.h>
#include <itkTIFFImageIO.h>

#include <tbb/tbb.h>
#include <time.h>
#include <math.h>
#include <iostream>
#include <fstream>
#include <eigen3/Eigen/Core>
#include <eigen3/Eigen/SparseCore>
#include <eigen3/Eigen/Sparse>
#include <eigen3/Eigen/SparseQR>
#include <eigen3/Eigen/SparseLU>
#include <eigen3/Eigen/SparseCholesky>
#include <eigen3/Eigen/IterativeLinearSolvers>
#include <eigen3/Eigen/UmfPackSupport>
#include <eigen3/Eigen/OrderingMethods>


#include <itkImage.h>
#include <itkVTKImageToImageFilter.h>
#include <itkImageToVTKImageFilter.h>
#include <itkImageFileWriter.h>
#include <itkTIFFImageIO.h>

typedef itk::Image<float, 3> ITKFloat3DImage;

using namespace csvision;

typedef itk::Image<unsigned char, 3> TypeLabelImage;
typedef itk::Image<double, 3> TypeDistanceImage;

vtkStandardNewMacro(swanIBSplineVTKImageSegmentFilter);

const int swanIBSplineVTKImageSegmentFilter::FLOW_CONSTANT = 0;
const int swanIBSplineVTKImageSegmentFilter::FLOW_CHANVESE = 1;

const int swanIBSplineVTKImageSegmentFilter::REGULAR_NONE  = 0;
const int swanIBSplineVTKImageSegmentFilter::REGULAR_DIAGONAL = 1;
const int swanIBSplineVTKImageSegmentFilter::REGULAR_TENSION  = 2;

swanIBSplineVTKImageSegmentFilter::swanIBSplineVTKImageSegmentFilter()
{
    this->SetNumberOfInputPorts(2);
    this->SetNumberOfOutputPorts(1);
    this->NumberOfBSpline = 20;
    this->epsilonH = 1.0e-5;
    this->epsilonD = 1.0e-1;
    this->tau   = 1.75e-1;
    this->nItor = 10;
    this->FlowVelc = FLOW_CHANVESE;
    this->Core.SetNumberOfSpline(NumberOfBSpline);
    this->ImageSampleRate = 10;
    this->RegularWeight = 1;
    
}

swanIBSplineVTKImageSegmentFilter::~swanIBSplineVTKImageSegmentFilter()
{
    
}

void swanIBSplineVTKImageSegmentFilter::SetDensity(int* DX, int* DY, int* DZ)
{
    for(int i = 0; i < NumberOfBSpline; i++){
        DensityX.push_back(*(DX+i));
        DensityY.push_back(*(DY+i));
        DensityZ.push_back(*(DZ+i));
    }
}

int swanIBSplineVTKImageSegmentFilter::FillInputPortInformation(int port, vtkInformation* info)
{
    if (port == 0) {
        // Original Image
        info->Set(vtkAlgorithm::INPUT_REQUIRED_DATA_TYPE(), "vtkImageData");
    }
    else if(port == 1) {
        // Init Shape
        info->Set(vtkAlgorithm::INPUT_REQUIRED_DATA_TYPE(), "vtkImageData");
    }
    return 1;
}

int swanIBSplineVTKImageSegmentFilter::RequestData(vtkInformation* request, vtkInformationVector** inputVector, vtkInformationVector* outputVector)
{
    vtkInformation* inInfoImgData = inputVector[0]->GetInformationObject(0);
    vtkImageData* inputImgData = vtkImageData::SafeDownCast(inInfoImgData->Get(vtkDataObject::DATA_OBJECT()));
    vtkInformation* inInfoIniData = inputVector[1]->GetInformationObject(0);
    vtkImageData* inputIniData = vtkImageData::SafeDownCast(inInfoIniData->Get(vtkDataObject::DATA_OBJECT()));
    
    vtkInformation* outInfo = outputVector->GetInformationObject(0);
    vtkImageData* output = vtkImageData::SafeDownCast(outInfo->Get(vtkDataObject::DATA_OBJECT()));
    
    
    //Init the initial shape and iteration
    int IniExtent[6] = {0};
    inputIniData->GetExtent(IniExtent);
    double IniSpacing[3] = {0.0};
    inputIniData->GetSpacing(IniSpacing);
    double IniOrigin[3] = {0.0};
    inputIniData->GetOrigin(IniOrigin);
    
    //Set the parameters for swanIBSpline3DHelper
    Core.SetNumberOfSpline(NumberOfBSpline);
    Core.SetRegularWeight(RegularWeight);
    Core.SetRegular(Regular);
    Core.SetisNonUniform(isNonUniform);
    if(isNonUniform)
        Core.SetDensity(DensityX, DensityY, DensityZ);
    
#ifdef __PROFILE__
    Profiler.AddLogNormal("Compute Distance Field", "swanIBSplineVTKImageSegmentFilter", "Start");
#endif
    
    typedef itk::VTKImageToImageFilter<TypeLabelImage> VTK2ITKType;
    typedef itk::SignedMaurerDistanceMapImageFilter<TypeLabelImage, TypeDistanceImage> SDFITKType;
    typedef itk::ImageToVTKImageFilter<TypeDistanceImage> ITK2VTKType;
    
    VTK2ITKType::Pointer VTK2ITKFilter = VTK2ITKType::New();
    VTK2ITKFilter->SetInput(inputIniData);
    VTK2ITKFilter->Update();
    
    SDFITKType::Pointer SDFITKFilter = SDFITKType::New();
    SDFITKFilter->SetInput(VTK2ITKFilter->GetOutput());
    SDFITKFilter->SetInsideIsPositive(true);
    SDFITKFilter->SetSquaredDistance(false);
    SDFITKFilter->SetUseImageSpacing(true);
    SDFITKFilter->Update();
    
    ITK2VTKType::Pointer ITK2VTKFilter = ITK2VTKType::New();
    ITK2VTKFilter->SetInput(SDFITKFilter->GetOutput());
    ITK2VTKFilter->Update();
    
    vtkSmartPointer<vtkImageData> SignedDistance = vtkSmartPointer<vtkImageData>::New();
    SignedDistance->DeepCopy(ITK2VTKFilter->GetOutput());
    
#ifdef __PROFILE__
    Profiler.AddLogNormal("Compute Distance Field", "swanIBSplineVTKImageSegmentFilter", "End");
#endif
    
#ifdef __PROFILE__
    Profiler.AddLogNormal("Sample Distance Field", "swanIBSplineVTKImageSegmentFilter", "Start");
#endif
    
    vtkSmartPointer<swanVTKImageGridSamplingFilter> sampleSignedDistance = vtkSmartPointer<swanVTKImageGridSamplingFilter>::New();
    sampleSignedDistance->SetSampFactor(ImageSampleRate);
    sampleSignedDistance->SetInputData(SignedDistance);
    sampleSignedDistance->Update();
    
    Point3DSet ControlPts;
    ControlPts.resize(sampleSignedDistance->GetNumSample());
    ColVectorX ControlFnv;
    ControlFnv.resize(sampleSignedDistance->GetNumSample());
    
    vtkSmartPointer<vtkDenseArray<double>> X = vtkDenseArray<double>::SafeDownCast(sampleSignedDistance->GetOutput()->GetArrayByName("X"));
    vtkSmartPointer<vtkDenseArray<double>> Y = vtkDenseArray<double>::SafeDownCast(sampleSignedDistance->GetOutput()->GetArrayByName("Y"));
    vtkSmartPointer<vtkDenseArray<double>> Z = vtkDenseArray<double>::SafeDownCast(sampleSignedDistance->GetOutput()->GetArrayByName("Z"));
    vtkSmartPointer<vtkDenseArray<double>> V = vtkDenseArray<double>::SafeDownCast(sampleSignedDistance->GetOutput()->GetArrayByName("V"));
    
    tbb::parallel_for(0, sampleSignedDistance->GetNumSample(), [&](int i) {
        ControlPts[i].X = X->GetValue(i);
        ControlPts[i].Y = Y->GetValue(i);
        ControlPts[i].Z = Z->GetValue(i);
        
        ControlFnv(i)   = V->GetValue(i);
    });

#ifdef __PROFILE__
    Profiler.AddLogNormal("Sample Distance Field", "swanIBSplineVTKImageSegmentFilter", "End");
#endif

#ifdef __PROFILE__
    Profiler.AddLogNormal("Kernelize", "swanIBSplineVTKImageSegmentFilter", "Start");
#endif
    Core.Kernelize(ControlPts);
    
#ifdef __PROFILE__
    Profiler.AddLogNormal("Kernelize", "swanIBSplineVTKImageSegmentFilter", "End");
#endif
    
#ifdef __PROFILE__
    Profiler.AddLogNormal("Factorize", "swanIBSplineVTKImageSegmentFilter", "Start");
#endif
    Core.Factorize();
#ifdef __PROFILE__
    Profiler.AddLogNormal("Factorize", "swanIBSplineVTKImageSegmentFilter", "End");
#endif

#ifdef __PROFILE__
    Profiler.AddLogNormal("Approximate", "swanIBSplineVTKImageSegmentFilter", "Start");
#endif
    ColVectorX Coeff = Core.Approximate(ControlFnv);
#ifdef __PROFILE__
    Profiler.AddLogNormal("Approximate Error", "swanIBSplineVTKImageSegmentFilter", "Sum:" + std::to_string(Core.ResidualError) + "; NumPoints:" + std::to_string(Core.ControlPts.size()) + "; Ave:" + std::to_string( (double)Core.ResidualError / (double)Core.ControlPts.size()));
    Profiler.AddLogNormal("Approximate", "swanIBSplineVTKImageSegmentFilter", "End");
#endif
    
    //Start the deformation for chan vese model
    if(FlowVelc == FLOW_CHANVESE) {
#ifdef __PROFILE__
        Profiler.AddLogNormal("Deform using Chan-Vese Model", "swanIBSplineVTKImageSegmentFilter", "Start");
#endif
        for (int n = 0; n < nItor; n++) {
            //Compute the C1/C2 using Chan-Vese Model
            int C1Length = 0;
            int C2Length = 0;
            double C1 = 0;
            double C2 = 0;
            //Can be parallelized by parallel_reduce
            for (int XI = IniExtent[0]; XI < IniExtent[1]; XI++) {
                for (int YI = IniExtent[2]; YI < IniExtent[3]; YI++) {
                    for (int ZI = IniExtent[4]; ZI < IniExtent[5]; ZI++) {
                        double VLev = SignedDistance->GetScalarComponentAsDouble(XI, YI, ZI, 0);
                        double VImg = inputImgData->GetScalarComponentAsDouble(XI, YI, ZI, 0)/255;
                        double HLab = RegularHeavi(VLev, epsilonH);
                        C1 += (1-VImg)*HLab;
                        C2 += (1-VImg)*(1-HLab);
                        if (VLev >= 0)
                            C1Length++;
                        else
                            C2Length++;
                    }
                }
            }
            
            
            if (C1Length == 0)
                C1 = 0;
            else
                C1 = C1/C1Length;
            
            if (C2Length == 0)
                C2 = 0;
            else
                C2 = C2/C2Length;
            
            std::cout<<C1<<"\t"<<C2<<std::endl;
            
            //Compute the velocity function for chan vese model and update the level set
            vtkSmartPointer<vtkImageData> tempVeloc = vtkSmartPointer<vtkImageData>::New();
            tempVeloc->SetExtent(IniExtent);
            tempVeloc->SetSpacing(IniSpacing);
            tempVeloc->AllocateScalars(VTK_DOUBLE, 1);
            tbb::parallel_for(IniExtent[0], IniExtent[1]+1, [&](int XI) {
                for (int YI = IniExtent[2]; YI < IniExtent[3]; YI++) {
                    for (int ZI = IniExtent[4]; ZI < IniExtent[5]; ZI++) {
                        double VLev = SignedDistance->GetScalarComponentAsDouble(XI, YI, ZI, 0);
                        double VImg = inputImgData->GetScalarComponentAsDouble(XI, YI, ZI, 0)/255;
                        // V = -((I - C1).^2) + (I - C2).^2
                        double Force = -pow(VImg-C1, 2) + pow(VImg-C2, 2);
                        // F = V * DiracDelta(Levelset)
                        double Veloc = Force * RegularDirac(VLev, epsilonD);
                        tempVeloc->SetScalarComponentFromDouble(XI, YI, ZI, 0, Veloc);
                        
//                        //Update the levelset avoid re-interpolating it using BSpline
//                        double ls = SignedDistance->GetScalarComponentAsDouble(XI, YI, ZI, 0);
//                        ls = ls - tau*Veloc;
//                        SignedDistance->SetScalarComponentFromDouble(XI, YI, ZI, 0, ls);
                    }
                }
            });
            
            //Solve the linear equation
            vtkSmartPointer<swanVTKImageGridSamplingFilter> velocFilter = vtkSmartPointer<swanVTKImageGridSamplingFilter>::New();
            velocFilter->SetInputData(tempVeloc);
            velocFilter->SetSampFactor(ImageSampleRate);
            velocFilter->Update();
            vtkSmartPointer<vtkDenseArray<double>> V = vtkDenseArray<double>::SafeDownCast(velocFilter->GetOutput()->GetArrayByName("V"));
            
            Eigen::VectorXd B(velocFilter->GetNumSample(), 1);
            tbb::parallel_for(0, velocFilter->GetNumSample(), [&](int i) {
                B(i) = V->GetValue(i);
            });
            
            Eigen::VectorXd CoeffVeloc = Core.GeneralSolve(B);
            
            //Update the coefficient
            tbb::parallel_for(0, (int)Coeff.size(), [&](int i) {
                Coeff(i) = Coeff(i)-tau*CoeffVeloc(i);
            });
            Core.SetCoeff(Coeff);
            
            if (n!=nItor-1)
            {
                vtkSmartPointer<swanVTKImageGridSamplingFilter> outputSample = vtkSmartPointer<swanVTKImageGridSamplingFilter>::New();
                outputSample->SetInputData(SignedDistance);
                outputSample->SetSampFactor(1);
                outputSample->Update();
                vtkSmartPointer<vtkDenseArray<double>> XX = vtkDenseArray<double>::SafeDownCast(outputSample->GetOutput()->GetArrayByName("X"));
                vtkSmartPointer<vtkDenseArray<double>> YY = vtkDenseArray<double>::SafeDownCast(outputSample->GetOutput()->GetArrayByName("Y"));
                vtkSmartPointer<vtkDenseArray<double>> ZZ = vtkDenseArray<double>::SafeDownCast(outputSample->GetOutput()->GetArrayByName("Z"));
                Point3DSet outputControlPts;
                outputControlPts.resize(outputSample->GetNumSample());
                tbb::parallel_for(0, outputSample->GetNumSample(), [&](int i) {
                    outputControlPts[i].X = XX->GetValue(i);
                    outputControlPts[i].Y = YY->GetValue(i);
                    outputControlPts[i].Z = ZZ->GetValue(i);
                });
                ColVectorX LS = Core.Interpolate(outputControlPts);
                
                tbb::parallel_for(IniExtent[0], IniExtent[1]+1, [&](int XI) {
                    for (int YI = IniExtent[2]; YI <= IniExtent[3]; YI++) {
                        for (int ZI = IniExtent[4]; ZI <= IniExtent[5]; ZI++) {
                            int Idx = XI * (IniExtent[3] - IniExtent[2] + 1) * (IniExtent[5] - IniExtent[4] + 1) + YI * (IniExtent[5] - IniExtent[4] + 1) + ZI;
                            SignedDistance->SetScalarComponentFromDouble(XI, YI, ZI, 0, LS(Idx));
                        }
                    }
                });
            }
            
            // I am stupid
            {
                std::string fn = "/Users/deng/Desktop/Aorta/EXP/Itor"+std::to_string(n+1)+".tif";
                typedef itk::VTKImageToImageFilter<ITKFloat3DImage> VTK2ITKType;
                typedef itk::ImageToVTKImageFilter<ITKFloat3DImage> ITK2VTKType;
                
                vtkSmartPointer<vtkImageCast> cast = vtkSmartPointer<vtkImageCast>::New();
                cast->SetInputData(SignedDistance);
                cast->SetOutputScalarTypeToFloat();
                cast->Update();
                
                VTK2ITKType::Pointer VTK2ITKFilter = VTK2ITKType::New();
                VTK2ITKFilter->SetInput(cast->GetOutput());
                VTK2ITKFilter->Update();
                
                typedef  itk::ImageFileWriter<ITKFloat3DImage> WriterType;
                typedef  itk::TIFFImageIO TIFFIOType;
                WriterType::Pointer writer = WriterType::New();
                TIFFIOType::Pointer tiffIO = TIFFIOType::New();
                tiffIO->SetPixelType(itk::ImageIOBase::RGBA);
                writer->SetFileName(fn.c_str());
                writer->SetInput(VTK2ITKFilter->GetOutput());
                writer->SetImageIO(tiffIO);
                writer->Update();
            }
        }
#ifdef __PROFILE__
        Profiler.AddLogNormal("Deform using Chan-Vese Model", "swanIBSplineVTKImageSegmentFilter", "End");
#endif
    }
    else if(FlowVelc == FLOW_CONSTANT){
#ifdef __PROFILE__
        Profiler.AddLogNormal("Deform using Constant Flow Model", "swanIBSplineVTKImageSegmentFilter", "Start");
#endif
        //Compute the constant coefficent velocity
        vtkSmartPointer<vtkImageData> tempVeloc = vtkSmartPointer<vtkImageData>::New();
        tempVeloc->SetExtent(IniExtent);
        tempVeloc->SetSpacing(IniSpacing);
        tempVeloc->AllocateScalars(VTK_DOUBLE, 1);
        tbb::parallel_for(IniExtent[0], IniExtent[1]+1, [&](int XI) {
            for (int YI = IniExtent[2]; YI < IniExtent[3]; YI++) {
                for (int ZI = IniExtent[4]; ZI < IniExtent[5]; ZI++) {
                    tempVeloc->SetScalarComponentFromDouble(XI, YI, ZI, 0, -1);
                }
            }
        });
        
        //Solve the linear equation
        vtkSmartPointer<swanVTKImageGridSamplingFilter> velocFilter = vtkSmartPointer<swanVTKImageGridSamplingFilter>::New();
        velocFilter->SetInputData(tempVeloc);
        velocFilter->SetSampFactor(ImageSampleRate);
        velocFilter->Update();
        vtkSmartPointer<vtkDenseArray<double>> V = vtkDenseArray<double>::SafeDownCast(velocFilter->GetOutput()->GetArrayByName("V"));
        
        Eigen::VectorXd B(velocFilter->GetNumSample(), 1);
        tbb::parallel_for(0, velocFilter->GetNumSample(), [&](int i) {
            B(i) = V->GetValue(i);
        });
        
        Eigen::VectorXd CoeffVeloc = Core.GeneralSolve(B);
        
        //Start the deformation for constant flow model
        for (int n = 0; n < nItor; n++) {
            tbb::parallel_for(0, (int)Coeff.size(), [&](int i) {
                Coeff(i) = Coeff(i)-tau*CoeffVeloc(i);
            });
        }
#ifdef __PROFILE__
        Profiler.AddLogNormal("Deform using Constant Flow Model", "swanIBSplineVTKImageSegmentFilter", "End");
#endif
    }
    
    
#ifdef __PROFILE__
    Profiler.AddLogNormal("Evaluate Surface", "swanIBSplineVTKImageSegmentFilter", "Start");
#endif
    //Construct the result using BSpline
    output->SetExtent(IniExtent);
    output->SetSpacing(IniSpacing);
    output->AllocateScalars(VTK_DOUBLE, 1);
    vtkSmartPointer<swanVTKImageGridSamplingFilter> outputSample = vtkSmartPointer<swanVTKImageGridSamplingFilter>::New();
    outputSample->SetInputData(output);
    outputSample->SetSampFactor(1);
    outputSample->Update();
    
    vtkSmartPointer<vtkDenseArray<double>> XX = vtkDenseArray<double>::SafeDownCast(outputSample->GetOutput()->GetArrayByName("X"));
    vtkSmartPointer<vtkDenseArray<double>> YY = vtkDenseArray<double>::SafeDownCast(outputSample->GetOutput()->GetArrayByName("Y"));
    vtkSmartPointer<vtkDenseArray<double>> ZZ = vtkDenseArray<double>::SafeDownCast(outputSample->GetOutput()->GetArrayByName("Z"));
    
    Point3DSet outputControlPts;
    outputControlPts.resize(outputSample->GetNumSample());
    tbb::parallel_for(0, outputSample->GetNumSample(), [&](int i) {
        outputControlPts[i].X = XX->GetValue(i);
        outputControlPts[i].Y = YY->GetValue(i);
        outputControlPts[i].Z = ZZ->GetValue(i);
    });
    ColVectorX LS = Core.Interpolate(outputControlPts);
    
    //Fill the output port and update the pipeline information
    tbb::parallel_for(IniExtent[0], IniExtent[1]+1, [&](int XI) {
        for (int YI = IniExtent[2]; YI <= IniExtent[3]; YI++) {
            for (int ZI = IniExtent[4]; ZI <= IniExtent[5]; ZI++) {
                int Idx = XI * (IniExtent[3] - IniExtent[2] + 1) * (IniExtent[5] - IniExtent[4] + 1) + YI * (IniExtent[5] - IniExtent[4] + 1) + ZI;
                output->SetScalarComponentFromDouble(XI, YI, ZI, 0, LS(Idx));
            }
        }
    });
#ifdef __PROFILE__
    Profiler.AddLogNormal("Evaluate Surface", "swanIBSplineVTKImageSegmentFilter", "End");
#endif
    
    outInfo->Set(vtkStreamingDemandDrivenPipeline::WHOLE_EXTENT(), IniExtent, 6);
    outInfo->Set(vtkStreamingDemandDrivenPipeline::UPDATE_EXTENT(), IniExtent, 6);
    
    return 1;
}

void swanIBSplineVTKImageSegmentFilter::save(std::string fn) {
    H5::H5File fMatrix(fn.c_str(), H5F_ACC_TRUNC);
    EigenHDF5::save_sparse(fMatrix, "K", Core.K);
    EigenHDF5::save_sparse(fMatrix, "M", Core.M);
    EigenHDF5::save_sparse(fMatrix, "H", Core.H);
    fMatrix.close();
}

void swanIBSplineVTKImageSegmentFilter::setCoreHelperPath(std::string fp){
    Core.SetHelperPath(fp);
}


double swanIBSplineVTKImageSegmentFilter::RegularDirac(double X, double eps)
{
    // delta = 1./(pi*epsilon*(1+(X./epsilon).^2));
    return 1.0 / (M_PI * eps * (1 + pow(X/eps, 2)));
}

double swanIBSplineVTKImageSegmentFilter::RegularHeavi(double X, double eps)
{
    // step = 0.5 * (1 + 2 * atan(X/epsilon)/pi);
    return 0.5 * (1 + 2 * atan(X/eps) / M_PI);
}


