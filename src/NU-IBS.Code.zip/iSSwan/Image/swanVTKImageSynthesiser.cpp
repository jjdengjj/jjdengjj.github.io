//
//  swanVTKImageSynthesiser.cpp
//  iSSwan
//
//  Created by Jingjing Deng on 20/04/2015.
//  Copyright (c) 2015 J. Deng. All rights reserved.
//

#include "swanVTKImageSynthesiser.h"

#include <vtkSmartPointer.h>
#include <vtkImageData.h>
#include <vtkType.h>

#include <tbb/tbb.h>
#include <math.h>

using namespace csvision;

swanVTKImageSynthesiser* swanVTKImageSynthesiser::_instance = NULL;

swanVTKImageSynthesiser::swanVTKImageSynthesiser()
{
    
}

swanVTKImageSynthesiser::~swanVTKImageSynthesiser()
{
    
}

swanVTKImageSynthesiser* swanVTKImageSynthesiser::getInstance()
{
    if(_instance == NULL)
    {
        _instance = new swanVTKImageSynthesiser();
        return _instance;
    }
    else
        return _instance;
}

void swanVTKImageSynthesiser::SynthCubeSS(vtkImageData* image, vtkImageData* signs)
{
    image->SetExtent(0, 511, 0, 511, 0, 511);
    image->SetSpacing(1.0f/512, 1.0f/512, 1.0f/512);
    image->AllocateScalars(VTK_DOUBLE, 1);
    
    signs->SetExtent(0, 511, 0, 511, 0, 511);
    signs->SetSpacing(1.0f/512, 1.0f/512, 1.0f/512);
    signs->AllocateScalars(VTK_SIGNED_CHAR, 1);
    
    tbb::parallel_for(0, 512, [&](int i) {
        for (int j = 0; j <= 511; j++) {
            for (int k = 0; k <= 511; k++) {
                double* pti = (double*)image->GetScalarPointer(i, j, k);
                char* pts = (char*)signs->GetScalarPointer(i, j, k);

                if(i>127 && i<384 &&
                   j>127 && j<384 &&
                   k>127 && k<384) {
                    *pti = 1.0;
                    *pts = 1;
                }
                else {
                    *pti = 0.0;
                    *pts = -1;
                }
                
            }
        }
    } );
    
    tbb::parallel_for(128, 384, [&](int i) {
        for(int j = 128; j <= 383; j++){
            char* pt1 = (char*)signs->GetScalarPointer(i, j, 128);
            *pt1 = 0;
            char* pt2 = (char*)signs->GetScalarPointer(i, j, 383);
            *pt2 = 0;
        }
    } );
    
    tbb::parallel_for(128, 384, [&](int i) {
        for(int k = 128; k <= 383; k++){
            char* pt1 = (char*)signs->GetScalarPointer(i, 128, k);
            *pt1 = 0;
            char* pt2 = (char*)signs->GetScalarPointer(i, 383, k);
            *pt2 = 0;
        }
    } );
    
    tbb::parallel_for(128, 384, [&](int j) {
        for(int k = 128; k <= 383; k++){
            char* pt1 = (char*)signs->GetScalarPointer(128, j, k);
            *pt1 = 0;
            char* pt2 = (char*)signs->GetScalarPointer(383, j, k);
            *pt2 = 0;
        }
    } );

}

void swanVTKImageSynthesiser::SynthSphereSS(vtkImageData* image, vtkImageData* signs)
{
    image->SetExtent(0, 511, 0, 511, 0, 511);
    image->SetSpacing(1.0f/512, 1.0f/512, 1.0f/512);
    image->AllocateScalars(VTK_DOUBLE, 1);
    
    signs->SetExtent(0, 511, 0, 511, 0, 511);
    signs->SetSpacing(1.0f/512, 1.0f/512, 1.0f/512);
    signs->AllocateScalars(VTK_SIGNED_CHAR, 1);
    
    tbb::parallel_for(0, 512, [&](int i) {
        for (int j = 0; j <= 511; j++) {
            for (int k = 0; k <= 511; k++) {
                double* pti = (double*)image->GetScalarPointer(i, j, k);
                char* pts = (char*)signs->GetScalarPointer(i, j, k);
                
                float d = pow(i-256,2) + pow(j-256,2) + pow(k-256,2) - pow(128,2);
                if(d<-0.5) {
                    *pti = 1.0;
                    *pts = 1;
                }
                else if(d>0.5) {
                    *pti = 0.0;
                    *pts = -1;
                }
                else {
                    *pti = 1.0;
                    *pts = 0;
                }
                
            }
        }
    } );
}

void swanVTKImageSynthesiser::SynthCubeSH(vtkImageData *image, vtkImageData *signs)
{
    image->SetExtent(0, 511, 0, 511, 0, 511);
    image->SetSpacing(1.0f/512, 1.0f/512, 1.0f/512);
    image->AllocateScalars(VTK_DOUBLE, 1);
    
    signs->SetExtent(0, 511, 0, 511, 0, 511);
    signs->SetSpacing(1.0f/512, 1.0f/512, 1.0f/512);
    signs->AllocateScalars(VTK_SIGNED_CHAR, 1);
    
    tbb::parallel_for(0, 512, [&](int i) {
        for (int j = 0; j <= 511; j++) {
            for (int k = 0; k <= 511; k++) {
                double* pti = (double*)image->GetScalarPointer(i, j, k);
                char* pts = (char*)signs->GetScalarPointer(i, j, k);
                
                if(i>129 && i<382 &&
                   j>129 && j<382 &&
                   k>129 && k<382) {
                    *pti = 0.0;
                    *pts = 1;
                }
                else if(i>127 && i<130 &&
                        j>127 && j<130 &&
                        k>127 && k<130) {
                    *pti = 1.0;
                    *pts = 0;
                }
                else {
                    *pti = 0.0;
                    *pts = -1;
                }
                
            }
        }
    } );
}

void swanVTKImageSynthesiser::SynthSphereSH(vtkImageData *image, vtkImageData *signs)
{
    image->SetExtent(0, 511, 0, 511, 0, 511);
    image->SetSpacing(1.0f/512, 1.0f/512, 1.0f/512);
    image->AllocateScalars(VTK_DOUBLE, 1);
    
    signs->SetExtent(0, 511, 0, 511, 0, 511);
    signs->SetSpacing(1.0f/512, 1.0f/512, 1.0f/512);
    signs->AllocateScalars(VTK_SIGNED_CHAR, 1);
    
    tbb::parallel_for(0, 512, [&](int i) {
        for (int j = 0; j <= 511; j++) {
            for (int k = 0; k <= 511; k++) {
                double* pti = (double*)image->GetScalarPointer(i, j, k);
                char* pts = (char*)signs->GetScalarPointer(i, j, k);
                
                float d = pow(i-256,2) + pow(j-256,2) + pow(k-256,2) - pow(128,2);
                if(d<-2) {
                    *pti = 0.0;
                    *pts = 1;
                }
                else if(d>0.5) {
                    *pti = 0.0;
                    *pts = -1;
                }
                else {
                    *pti = 1.0;
                    *pts = 0;
                }
                
            }
        }
    } );
}

