//
//  swanVTKImageGridSamplingFilter.h
//  iSSwan
//
//  Created by Jingjing Deng on 01/04/2015.
//  Copyright (c) 2015 J. Deng. All rights reserved.
//

#ifndef __iSSwan__swanVTKImageGridSamplingFilter__
#define __iSSwan__swanVTKImageGridSamplingFilter__

#include <stdio.h>

#include <vtkArrayDataAlgorithm.h>

namespace csvision {
    class swanVTKImageGridSamplingFilter : public vtkArrayDataAlgorithm
    {
    protected:
        swanVTKImageGridSamplingFilter();
        ~swanVTKImageGridSamplingFilter();
        virtual int FillInputPortInformation(int port, vtkInformation* info);
        virtual int RequestData(vtkInformation* request, vtkInformationVector** inputVector, vtkInformationVector* outputVector);
        
    private:
        swanVTKImageGridSamplingFilter(const swanVTKImageGridSamplingFilter&);
        bool operator=(const swanVTKImageGridSamplingFilter&);
        int SampFactor;
        int NumSample;
        
    public:
        static swanVTKImageGridSamplingFilter* New();
        vtkTypeMacro(swanVTKImageGridSamplingFilter, vtkArrayDataAlgorithm);
        void PrintSelf(std::ostream, vtkIndent);
        
        vtkSetMacro(SampFactor, int);
        vtkGetMacro(SampFactor, int);
        vtkGetMacro(NumSample, int);
    };
}

#endif /* defined(__iSSwan__swanVTKImageGridSamplingFilter__) */
