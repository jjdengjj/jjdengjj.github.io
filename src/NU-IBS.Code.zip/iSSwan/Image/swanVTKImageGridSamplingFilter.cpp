//
//  swanVTKImageGridSamplingFilter.cpp
//  iSSwan
//
//  Created by Jingjing Deng on 01/04/2015.
//  Copyright (c) 2015 J. Deng. All rights reserved.
//

#include "swanVTKImageGridSamplingFilter.h"

#include <tbb/tbb.h>
#include <vtkObjectFactory.h>
#include <vtkInformation.h>
#include <vtkInformationVector.h>
#include <vtkSmartPointer.h>
#include <vtkArrayData.h>
#include <vtkImageData.h>
#include <vtkDataArray.h>
#include <vtkDoubleArray.h>
#include <vtkDenseArray.h>
#include <vtkArray.h>

using namespace csvision;

vtkStandardNewMacro(swanVTKImageGridSamplingFilter);

swanVTKImageGridSamplingFilter::swanVTKImageGridSamplingFilter()
{
    this->SampFactor = 1;
    this->NumSample = -1;
}

swanVTKImageGridSamplingFilter::~swanVTKImageGridSamplingFilter()
{
    
}

int swanVTKImageGridSamplingFilter::FillInputPortInformation(int port, vtkInformation* info)
{
    info->Set(vtkAlgorithm::INPUT_REQUIRED_DATA_TYPE(), "vtkImageData");
    return 1;
}

int swanVTKImageGridSamplingFilter::RequestData(vtkInformation* request, vtkInformationVector** inputVector, vtkInformationVector* outputVector)
{
    vtkInformation* inInfo = inputVector[0]->GetInformationObject(0);
    vtkInformation* outInfo = outputVector->GetInformationObject(0);
    vtkImageData* input = vtkImageData::SafeDownCast(inInfo->Get(vtkDataObject::DATA_OBJECT()));
    vtkArrayData* output = vtkArrayData::SafeDownCast(outInfo->Get(vtkDataObject::DATA_OBJECT()));
    
    int extent[6] = {0};
    double space[3] = {0.0};
    input->GetExtent(extent);
    input->GetSpacing(space);
    
    int XMax = floor((extent[1]-extent[0])/SampFactor)+1;
    int YMax = floor((extent[3]-extent[2])/SampFactor)+1;
    int ZMax = floor((extent[5]-extent[4])/SampFactor)+1;
    int num = XMax * YMax * ZMax;
    vtkSmartPointer<vtkDenseArray<double>> X = vtkSmartPointer<vtkDenseArray<double>>::New();
    vtkSmartPointer<vtkDenseArray<double>> Y = vtkSmartPointer<vtkDenseArray<double>>::New();
    vtkSmartPointer<vtkDenseArray<double>> Z = vtkSmartPointer<vtkDenseArray<double>>::New();
    vtkSmartPointer<vtkDenseArray<double>> V = vtkSmartPointer<vtkDenseArray<double>>::New();
    X->SetName("X");
    Y->SetName("Y");
    Z->SetName("Z");
    V->SetName("V");
    X->Resize(num);
    Y->Resize(num);
    Z->Resize(num);
    V->Resize(num);

    
    tbb::parallel_for(0, XMax, [&](int i) {
        int ii = extent[0] + i * SampFactor;
        for (int j = 0; j<YMax; j++) {
            int jj = extent[2] + j * SampFactor;
            for (int k = 0; k<ZMax; k++) {
                int kk = extent[4] + k * SampFactor;
                int n = i * YMax * ZMax + j * ZMax + k;
                X->SetValue(n, ii*space[0]);
                Y->SetValue(n, jj*space[1]);
                Z->SetValue(n, kk*space[2]);
                V->SetValue(n, input->GetScalarComponentAsDouble(ii, jj, kk, 0));
            }
        }
    });

    output->AddArray(X);
    output->AddArray(Y);
    output->AddArray(Z);
    output->AddArray(V);
    
    this->NumSample = num;
    
    return 1;
}
