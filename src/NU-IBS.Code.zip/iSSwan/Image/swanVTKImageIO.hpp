//
//  swanVTKImageIO.hpp
//  iSSwan
//
//  Created by Jingjing Deng on 30/04/2015.
//
//

#ifndef iSSwan_swanVTKImageIO_hpp
#define iSSwan_swanVTKImageIO_hpp

#include <vtkSmartPointer.h>
#include <vtkImageData.h>
#include <vtkXMLImageDataWriter.h>
#include <vtkXMLImageDataReader.h>
#include <vtkTIFFReader.h>
#include <vtkStringArray.h>
#include <vtkImageCast.h>

#include <itkImage.h>
#include <itkVTKImageToImageFilter.h>
#include <itkImageToVTKImageFilter.h>
#include <itkImageFileWriter.h>
#include <itkTIFFImageIO.h>

#include <dirent.h>
#include <string>

typedef itk::Image<float, 3> ITKFloat3DImage;

namespace csvision {
    
    // VTK Side
    void VTKImageSaveToVTI(std::string fn, const vtkSmartPointer<vtkImageData> img) {
        //Save to disk
        vtkSmartPointer<vtkXMLImageDataWriter> todisk = vtkSmartPointer<vtkXMLImageDataWriter>::New();
        todisk->SetFileName(fn.c_str());
        todisk->SetInputData(img);
        todisk->Write();
    };
    
    void VTKImageLoadFromVTI(std::string fn, vtkSmartPointer<vtkImageData> img) {
        //Load to memory
        vtkSmartPointer<vtkXMLImageDataReader> fromdisk = vtkSmartPointer<vtkXMLImageDataReader>::New();
        fromdisk->SetFileName(fn.c_str());
        fromdisk->Update();
        img->DeepCopy(fromdisk->GetOutput());
    };
    
    void VTKImageLoadFromTIF(std::string fn, vtkSmartPointer<vtkImageData> img) {
        //Load to memory
        vtkSmartPointer<vtkTIFFReader> fromdisk = vtkSmartPointer<vtkTIFFReader>::New();
        fromdisk->SetFileName(fn.c_str());
        fromdisk->Update();
        img->DeepCopy(fromdisk->GetOutput());
    }
    
    void VTKImageSaveToTIF(std::string fn, vtkSmartPointer<vtkImageData> img) {
        typedef itk::VTKImageToImageFilter<ITKFloat3DImage> VTK2ITKType;
        typedef itk::ImageToVTKImageFilter<ITKFloat3DImage> ITK2VTKType;
        
        vtkSmartPointer<vtkImageCast> cast = vtkSmartPointer<vtkImageCast>::New();
        cast->SetInputData(img);
        cast->SetOutputScalarTypeToFloat();
        cast->Update();
        
        VTK2ITKType::Pointer VTK2ITKFilter = VTK2ITKType::New();
        VTK2ITKFilter->SetInput(cast->GetOutput());
        VTK2ITKFilter->Update();
        
        typedef  itk::ImageFileWriter<ITKFloat3DImage> WriterType;
        typedef  itk::TIFFImageIO TIFFIOType;
        WriterType::Pointer writer = WriterType::New();
        TIFFIOType::Pointer tiffIO = TIFFIOType::New();
        tiffIO->SetPixelType(itk::ImageIOBase::RGBA);
        writer->SetFileName(fn.c_str());
        writer->SetInput(VTK2ITKFilter->GetOutput());
        writer->SetImageIO(tiffIO);
        writer->Update();
    }
    
    // ITK Side
    void ITKFloat3DImageSaveToTIF(std::string fn, ITKFloat3DImage::Pointer img) {
        typedef  itk::ImageFileWriter<ITKFloat3DImage> WriterType;
        typedef  itk::TIFFImageIO TIFFIOType;
        WriterType::Pointer writer = WriterType::New();
        TIFFIOType::Pointer tiffIO = TIFFIOType::New();
        tiffIO->SetPixelType(itk::ImageIOBase::RGBA);
        writer->SetFileName(fn.c_str());
        writer->SetInput(img);
        writer->SetImageIO(tiffIO);
        writer->Update();
    }
}

#endif
