//
//  swanVTKImageSynthesiser.h
//  iSSwan
//
//  Created by Jingjing Deng on 20/04/2015.
//  Copyright (c) 2015 J. Deng. All rights reserved.
//

#ifndef __iSSwan__swanVTKImageSynthesiser__
#define __iSSwan__swanVTKImageSynthesiser__

#include <stdio.h>

#include <vtkSmartPointer.h>
#include <vtkImageData.h>

namespace csvision {
    class swanVTKImageSynthesiser
    {
    //COMMENT-START
    //Singleton Pattern
    protected:
        swanVTKImageSynthesiser();
        ~swanVTKImageSynthesiser();
    private:
        static swanVTKImageSynthesiser* _instance;
    public:
        static swanVTKImageSynthesiser* getInstance();
    //COMMENT-END
     
        //Name Coding
        //S->Single, D->Double, Q->Quadruple
        //S->Solid,  H->Hollow
        //Inside->Pos, Outside->Neg, On->Nil
    public:
        void SynthCubeSS(vtkImageData* image, vtkImageData* signs);
        void SynthSphereSS(vtkImageData* image, vtkImageData* signs);
        void SynthCubeSH(vtkImageData* image, vtkImageData* signs);
        void SynthSphereSH(vtkImageData* image, vtkImageData* signs);
        
    };
}

#endif /* defined(__iSSwan__swanVTKImageSynthesiser__) */