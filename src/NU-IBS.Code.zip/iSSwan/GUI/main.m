//
//  main.m
//  GUI
//
//  Created by Jingjing Deng on 30/04/2015.
//
//

#import <Cocoa/Cocoa.h>

int main(int argc, const char * argv[]) {
    return NSApplicationMain(argc, argv);
}
