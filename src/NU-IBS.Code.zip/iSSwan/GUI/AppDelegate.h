//
//  AppDelegate.h
//  GUI
//
//  Created by Jingjing Deng on 30/04/2015.
//
//

#import <Cocoa/Cocoa.h>

@interface AppDelegate : NSObject <NSApplicationDelegate>


@end

