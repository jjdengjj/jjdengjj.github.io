iSSwan stands for Interactive Segmentation Toolkit Swansea University

1. Aims

2. Project Requirements
(a) ITK
(b) VTK
(c) TBB
(d) Eigen3
(e) OpenCL
(f) suiteSparse
(g) ViennaCL
(h) clMath (clBLAS, clFFT)
(i) Accelerate.framework